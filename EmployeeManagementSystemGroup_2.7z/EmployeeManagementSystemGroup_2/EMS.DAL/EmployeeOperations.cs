﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exception;


namespace EMS.DAL
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 25/03/2017
    /// Change Description : 
    /// </summary>
    public class EmployeeOperations
    {
        // Employee Methods
        // Update method for Employee
        #region Employee

            public static int UpdateEmployee(Employee emp)
            {
                int recordsAffected = 0;

                try
                {
                    SqlCommand cmd = DataConfiguration.CreateCommand();

                    cmd.CommandText = "Employee_UpdateEmployee";

                    cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                    cmd.Parameters.AddWithValue("@Address", emp.Address);
                    cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                    cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);

                    cmd.Connection.Open();
                    recordsAffected = cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }

                catch (SystemException ex)
                {

                    throw ex;
                }
                return recordsAffected;
            }

            // method to search his profile
            public static DataTable viewEmpProfile(int empID)
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlCommand cmd = DataConfiguration.CreateCommand();
                    cmd.CommandText = "Admin_SearchEmployee";

                    cmd.Parameters.AddWithValue("@EmpID", empID);

                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        dt.Load(dr);
                    }
                    else
                    {
                        throw new EmployeeException("Employee Data not Available");
                    }
                    cmd.Connection.Close();
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {

                    throw ex;
                }
                return dt;
            }

            //Employee's Timesheet display method

            public static DataTable ViewEmpShift(int empID)
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlCommand cmd = DataConfiguration.CreateCommand();
                    cmd.CommandText = "RetrieveEmpShftInfo";

                    cmd.Parameters.AddWithValue("@EmpID", empID);

                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        dt.Load(dr);
                    }
                    else
                    {
                        throw new EmployeeException("Employee shift details not Available");
                    }
                    cmd.Connection.Close();
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {

                    throw ex;
                }
                return dt;
            }

            //Employee method to View Project Details

            public static DataTable SearchProjDetails(string projID)
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlCommand cmd = DataConfiguration.CreateCommand();
                    cmd.CommandText = "Employee_DisplayProject";

                    cmd.Parameters.AddWithValue("@ProjectID", projID);


                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        dt.Load(dr);
                    }
                    else
                    {
                        throw new EmployeeException("Employee project details not Available");
                    }
                    cmd.Connection.Close();
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {

                    throw ex;
                }

                return dt;
            }

            // method to search any employee
            public static Employee SearchEmployee(int empID)
            {
                Employee emp = null;

                try
                {
                    SqlCommand cmd = DataConfiguration.CreateCommand();
                    cmd.CommandText = "Employee_SearchEmployee";

                    cmd.Parameters.AddWithValue("@EmpID", empID);

                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        dr.Read();
                        emp = new Employee();
                        emp.EmployeeID = Convert.ToInt32(dr["EmpID"]);
                        emp.FirstName = dr["FirstName"].ToString();
                        //emp.LastName = dr["LastName"].ToString();
                        //emp.DOB = Convert.ToDateTime(dr["DateOfBirth"]);
                        //emp.DOJ = Convert.ToDateTime(dr["DateOfJoining"]);
                        //emp.Gender = dr["Gender"].ToString();
                        //emp.Address = dr["Address"].ToString();
                        //emp.MaritalStatus = dr["MaritalStatus"].ToString();
                        //emp.Salary = Convert.ToInt32(dr["Salary"]);
                        //emp.PhoneNo = dr["PhoneNumber"].ToString();
                        emp.DesignationID = dr["DesigCode"].ToString();
                        emp.DepartmentID = Convert.ToInt32(dr["DeptID"]);
                        //emp.ManagerID = Convert.ToInt32(dr["MgrID"]);
                        //emp.GradeCode = dr["GradeCode"].ToString();
                    }
                    else
                    {
                        throw new EmployeeException("Employee not found with id" + empID);
                    }
                    cmd.Connection.Close();
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {

                    throw ex;
                }
                return emp;
            }


            //Login for Employee Details
            public static string ValidateLogin(UserMaster user)
            {
                string userName = null;

                try
                {
                    SqlCommand cmd = DataConfiguration.CreateCommand();
                    cmd.CommandText = "EMS.ValidateLogin";

                    cmd.Parameters.AddWithValue("@UserName", user.UserName);
                    cmd.Parameters.AddWithValue("@Password", user.Password);

                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();
                        userName = dr[0].ToString();
                    }
                    else
                    {
                        throw new EmployeeException("User Name/Password is invalid");
                    }

                    cmd.Connection.Close();
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return userName;
            }
        #endregion
    }
}