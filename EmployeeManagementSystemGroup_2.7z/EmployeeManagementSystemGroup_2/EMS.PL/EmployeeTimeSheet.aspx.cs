﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class EmployeeTimeSheet : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] == null || Session["Employee"] == String.Empty)
            {
                Response.Redirect("EmployeeActivity.aspx");

            }
            else
            {

                lblUser.Text = Session["Employee"].ToString();
            }
        }

        protected void btnTymShft_Click(object sender, EventArgs e)
        {

            try
            {
                int empID = Convert.ToInt32(txtTymEmpID.Text);
                DataTable table = new DataTable();
                table = EmployeeValidation.ViewEmpShift(empID);
                if (table != null)
                {
                    txtTymShftID.Text = table.Rows[0]["ShiftID"].ToString();
                    
                }
                else
                {
                    string message = "Employee not found with this id : " + empID;
                    throw new AdminException(message);
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void Back_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeActivity.aspx");
        }
    }
}