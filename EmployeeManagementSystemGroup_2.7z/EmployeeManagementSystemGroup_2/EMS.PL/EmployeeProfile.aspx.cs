﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 10/04/2017
    /// Change Description : 
    /// </summary>
    public partial class EmployeeProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //lblEmpUser.Text = Session["Employee"].ToString();
            //string UserName = Session["Employee"].ToString();
            //DataTable table = new DataTable();
            //table = EmployeeValidation.viewEmpProfile(UserName);

            //if (table != null)
            //{
            //    lblEmplyId.Text = table.Rows[0]["EmpID"].ToString();
            //    lblFirstName.Text = table.Rows[0]["FirstName"].ToString();
            //    lblLastName.Text = table.Rows[0]["LastName"].ToString();
            //    lblDOB.Text = table.Rows[0]["DateOfBirth"].ToString();
            //    lblDOJ.Text = table.Rows[0]["DateOfJoining"].ToString();
            //    lblGender.Text = table.Rows[0]["Gender"].ToString();


            //    lblAddress.Text = table.Rows[0]["Address"].ToString();
            //    lblMstatus.Text = table.Rows[0]["MaritalStatus"].ToString();
            //    lblSal.Text = table.Rows[0]["Salary"].ToString();
            //    lblPhnNumber.Text = table.Rows[0]["PhoneNumber"].ToString();
            //    lblDesg.Text = table.Rows[0]["DesigCode"].ToString();
            //    lblDept.Text = table.Rows[0]["DeptID"].ToString();
            //    lblMgrCode.Text = table.Rows[0]["MgrID"].ToString();
            //    lblGrdCode.Text = table.Rows[0]["GradeCode"].ToString();

            //}
            //else
            //{
            //    Response.Write("Record Not Found");
            //}

            DataTable dt = new DataTable();
            lblEmpUser.Text = Session["Employee"].ToString();
            string UserName = Session["Employee"].ToString();
            dt = EmployeeValidation.MyProfile(UserName);

            if (dt != null)
            {
                lblEmplyId.Text = dt.Rows[0]["EmpID"].ToString();
                lblFirstName.Text = dt.Rows[0]["FirstName"].ToString();
                lblLastName.Text = dt.Rows[0]["LastName"].ToString();
                lblDOB.Text = dt.Rows[0]["DateOfBirth"].ToString();
                lblDOJ.Text = dt.Rows[0]["DateOfJoining"].ToString();
                lblGender.Text = dt.Rows[0]["Gender"].ToString();


                lblAddress.Text = dt.Rows[0]["Address"].ToString();
                lblMstatus.Text = dt.Rows[0]["MaritalStatus"].ToString();
                lblSal.Text = dt.Rows[0]["Salary"].ToString();
                lblPhnNumber.Text = dt.Rows[0]["PhoneNumber"].ToString();
                lblDesg.Text = dt.Rows[0]["DesigCode"].ToString();
                lblDept.Text = dt.Rows[0]["DeptID"].ToString();
                lblMgrCode.Text = dt.Rows[0]["MgrID"].ToString();
                lblGrdCode.Text = dt.Rows[0]["GradeCode"].ToString();

            }
            else
            {
                Response.Write("Record Not Found");
            }

            //try
            //{
            //    int empID = Convert.ToInt32(txtempID.Text);
            //     Employee emp = AdminValidation.SearchEmployee(empID);
            //    if (emp != null)
            //    {
            //        txtFirstName.Text = emp.FirstName;//dt.Rows[0]["FirstName"].ToString();
            //        txtLastName.Text = emp.LastName; //dt.Rows[0]["LastName"].ToString();
            //        txtDOB.Text = emp.DOB.ToString();//dt.Rows[0]["DateOfBirth"].ToString();
            //        txtDOJ.Text = emp.DOJ.ToString();//dt.Rows[0]["DateOfJoining"].ToString();
            //        ddlGender.SelectedItem.Text = emp.Gender;//dt.Rows[0]["Gender"].ToString();
            //        txtAddress.Text = emp.Address;//dt.Rows[0]["Address"].ToString();
            //        ddlMStatus.SelectedItem.Text = emp.MaritalStatus;//dt.Rows[0]["MaritalStatus"].ToString();
            //        txtSalary.Text = emp.Salary.ToString();//dt.Rows[0]["Salary"].ToString();
            //        txtPhoneNumber.Text = emp.PhoneNo;//dt.Rows[0]["PhoneNumber"].ToString();
            //        ddlDesg.SelectedItem.Text = emp.DesignationID;//dt.Rows[0]["DesigCode"].ToString();
            //        ddlDept.SelectedItem.Text = emp.DepartmentID.ToString();//dt.Rows[0]["DesigCode"].ToString();
            //        txtMgrCode.Text = emp.ManagerID.ToString();//dt.Rows[0]["MgrID"].ToString();
            //        ddlGradeCode.SelectedItem.Text = emp.GradeCode;//dt.Rows[0]["GradeCode"].ToString();
            //    }
            //    else
            //    {
            //        string message = "Employee not found with this id : " + empID;
            //        throw new AdminException(message);
             // }

        }

        protected void btnEmpUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.EmployeeID = Convert.ToInt32(txtEmpId.Text);
                emp.FirstName = txtEmpFrstName.Text;
                emp.LastName = txtEmpLstName.Text;
                emp.DOB = Convert.ToDateTime(txtEmpDOB.Text);
                emp.Address = txtEmpAdres.Text;
                emp.MaritalStatus = ddlEmpMStatus.SelectedItem.Text;
                emp.PhoneNo = txtEmpPhnNo.Text;

                int recordsAffected = EmployeeValidation.UpdateEmployee(emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee Updated successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Employee Not Updated");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}