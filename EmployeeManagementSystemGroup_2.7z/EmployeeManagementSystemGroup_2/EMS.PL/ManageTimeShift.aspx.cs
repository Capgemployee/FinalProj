﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 09/04/2017
    /// Change Description : 
    public partial class ManageTimeShift : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        protected void btnDisplyShft_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = AdminValidation.DislpayTimesheetDetails();
                if (dt.Rows.Count > 0)
                {
                    gvDisplayShft.DataSource = dt;
                    gvDisplayShft.DataBind();
                }
                else
                    throw new AdminException("Time Shift Details not Available");
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void imgbtnTymSDisplay_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int empID = Convert.ToInt32(txtShftEmpid.Text);
                EmployeeShiftDetails emp = AdminValidation.SearchEmpShift(empID);
                if (emp != null)
                {
                    gvDisplayShft.DataSource = new List<EmployeeShiftDetails> { emp };
                    gvDisplayShft.DataBind();
                }
                else
                {
                    string message = "Employee not found with id : " + empID;
                    throw new AdminException(message);
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnAssignShft_Click(object sender, EventArgs e)
        {
            try
            {
                EmployeeShiftDetails empShft = new EmployeeShiftDetails();
                empShft.EmployeeID = Convert.ToInt32(txtTymEmpid.Text);
                empShft.ShiftID = txtTymShftid.Text;

                int recordsAffected = AdminValidation.AssignShift(empShft);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Time Shift Assign successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Unable to Assign the Project");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdateShft_Click(object sender, EventArgs e)
        {
            try
            {
                EmployeeShiftDetails empShft = new EmployeeShiftDetails();
                empShft.EmployeeID = Convert.ToInt32(txtTymEmpid.Text);
                empShft.ShiftID = txtTymShftid.Text;

                int recordsAffected = AdminValidation.UpdateShift(empShft);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Time Shift Details Updated successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Unable to Update the Shift Details");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminActivity.aspx");
        }
    }
}