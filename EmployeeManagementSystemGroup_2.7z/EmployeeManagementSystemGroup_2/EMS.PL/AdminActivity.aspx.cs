﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 08/04/2017
    /// Change Description : 
    /// </summary>
    public partial class AdminActivity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        protected void btnEmpsection_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEmpManage.aspx");
        }

        protected void btnLogOut_Click(object sender, EventArgs e)
        {

            Response.Redirect("Welcome.aspx");
        }

        protected void btnDept_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageDepartment.aspx");
        }

        protected void btnProj_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageProject.aspx");        
        }

        protected void btnCrtLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateLogin.aspx");
        }

        protected void btnTymShft_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageTimeShift.aspx");
        }
    }
}