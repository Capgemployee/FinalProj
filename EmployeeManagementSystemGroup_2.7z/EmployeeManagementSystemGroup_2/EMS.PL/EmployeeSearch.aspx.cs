﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 09/04/2017
    /// Change Description : 
    /// </summary>

    public partial class EmployeeSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEmpDetails_Click(object sender, EventArgs e)
        {
            try
            {
                int empID = Convert.ToInt32(txtEmpID.Text);
                Employee emp = EmployeeValidation.SearchEmployee(empID);
                if (emp != null)
                {
                    txtEmpName.Text = emp.FirstName;
                    txtDesig.Text = emp.DesignationID;
                    txtDepart.Text = emp.DepartmentID.ToString();
                }
                else
                {
                    string message = "Employee not found with id : " + empID;
                    throw new EmployeeException(message);
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}