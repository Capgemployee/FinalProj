﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Author : 
    /// Modification Date : 
    /// Change Description : 
    /// </summary>
    public class EmployeeException : ApplicationException
    {
        #region Constructors

        public EmployeeException()
            : base()
        { }

        public EmployeeException(string message) : base (message)
        { }

        #endregion
    }
}
