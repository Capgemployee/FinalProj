﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using EMS.Exception;
using EMS.Entity;
using EMS.DAL;
using System.Data;

namespace EMS.BL
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 25/03/2017
    /// Change Description : 
    /// </summary>
    public class EmployeeValidation
    {
        #region Employee

            // Update method for Employee
            public static int UpdateEmployee(Employee emp)
            {
                int recordsAffected = 0;

                try
                {
                    recordsAffected = EmployeeOperations.UpdateEmployee(emp);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return recordsAffected;
            }

            // Method to search his profile
            public static DataTable viewEmpProfile(int empID)
            {
                DataTable dt = null;

                try
                {
                    dt = EmployeeOperations.viewEmpProfile(empID);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }

            //Employee's Timesheet display method
            public static DataTable ViewEmpShift(int empID)
            {
                DataTable dt = null;

                try
                {
                    dt = EmployeeOperations.ViewEmpShift(empID);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }

            //Employee method to View Project Details
            public static DataTable SearchProjDetails(string projID)
            {
                DataTable dt = null;

                try
                {
                    dt = EmployeeOperations.SearchProjDetails(projID);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }

            // method to search any employee
            public static Employee SearchEmployee(int empID)
            {
                Employee emp = null;

                try
                {
                    emp = EmployeeOperations.SearchEmployee(empID);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return emp;
            }

            //Login for Employee Details
            public static string ValidateLogin(UserMaster user)
            {
                string userName = null;

                try
                {
                    userName = EmployeeOperations.ValidateLogin(user);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return userName;
            }
            // To view emnployee profile
            public static DataTable MyProfile(string UserName)
            {
                DataTable dt = null;

                try
                {
                    dt = EmployeeOperations.MyProfile(UserName);
                }
                catch (EmployeeException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }
        #endregion
    }
}
