package com.cg.ars.exception;

public class AirlineException extends Exception {
	
	public AirlineException(String message)
	{
		super(message);
	}

}
