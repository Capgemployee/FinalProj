package com.cg.ars.bean;

public class FlightInfoBean {

	private String flightNo, airline, deptCity, arrCity, deptTime, arrTime, deptDate, arrDate;
	private int firstSeats, bussSeats;
	private float firstSeatFare, bussSeatFare;
	
	public String getFlightNo() {
		return flightNo;
	}
	
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	
	public String getAirline() {
		return airline;
	}
	
	public void setAirline(String airline) {
		this.airline = airline;
	}
	
	public String getDeptCity() {
		return deptCity;
	}
	
	public void setDeptCity(String deptCity) {
		this.deptCity = deptCity;
	}
	
	public String getArrCity() {
		return arrCity;
	}
	
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	
	public String getDeptTime() {
		return deptTime;
	}
	
	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}
	
	public String getArrTime() {
		return arrTime;
	}
	
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	
	public String getDeptDate() {
		return deptDate;
	}
	
	public void setDeptDate(String deptDate) {
		this.deptDate = deptDate.substring(0, 10);
	}
	
	public String getArrDate() {
		return arrDate;
	}
	
	public void setArrDate(String arrDate) {
		this.arrDate = arrDate.substring(0, 10);
	}
	
	public int getFirstSeats() {
		return firstSeats;
	}
	
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	
	public int getBussSeats() {
		return bussSeats;
	}
	
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	
	public float getFirstSeatFare() {
		return firstSeatFare;
	}
	
	public void setFirstSeatFare(float firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	
	public float getBussSeatFare() {
		return bussSeatFare;
	}
	
	public void setBussSeatFare(float bussSeatFare) {
		this.bussSeatFare = bussSeatFare;
	}
	
	
}
