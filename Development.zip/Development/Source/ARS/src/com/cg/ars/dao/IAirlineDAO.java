package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.bean.BookingInfoBean;
import com.cg.ars.bean.CustomerBean;
import com.cg.ars.bean.FlightInfoBean;
import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.AirlineException;

public interface IAirlineDAO {

	public boolean isValidAuthority(UserBean user) throws AirlineException;
	public boolean isValidUser(UserBean user) throws AirlineException;
	public boolean isAvailableUsername(CustomerBean customer) throws AirlineException;
	public boolean addNewPassenger(CustomerBean customer, UserBean user) throws AirlineException;
	public List<String> findDepartureCities() throws AirlineException;
	public List<String> findArrivalCities() throws AirlineException;
	public List<FlightInfoBean> searchFlightDetails(String deptCity, String arrCity, String deptDate) throws AirlineException;
	public boolean isSeatAvailable(String flightNo, String seatType, String seatNum) throws AirlineException;
	public String getCustomerMail(String username) throws AirlineException;
	public String getCustomerName(String username) throws AirlineException;
	public String getTotalFare(String flightNo, String seatType, String seatNum) throws AirlineException;
	public int bookFlight(BookingInfoBean book) throws AirlineException;
	public boolean updateSeatNum(BookingInfoBean book) throws AirlineException;
	public List<BookingInfoBean> getCustomerBookingInfo(String username) throws AirlineException;
	public boolean isValidBookingId(String bookingId, String username) throws AirlineException;
	public boolean deleteCustomerBooking(String bookingId) throws AirlineException;
	public List<String> flightNoListDate(String deptDate, String arrDate) throws AirlineException;
	public List<BookingInfoBean> viewFlightOccupancy(List<String> flightNoList) throws AirlineException;
	public List<String> flightNoListCity(String srcCity, String destCity) throws AirlineException;
	public boolean insertFlightDetails(FlightInfoBean flight) throws AirlineException;
	public boolean isAvailableFlightNo(String flightNo) throws AirlineException;
	public boolean deleteFlightDetails(String flightNo) throws AirlineException;
	public List<FlightInfoBean> viewAllFlightSchedules() throws AirlineException;
	public FlightInfoBean viewFlightSchedule(String flightNo) throws AirlineException;
	public List<CustomerBean> getPassengerList(String flightNo) throws AirlineException;
	public List<BookingInfoBean> getBookingList(String flightNo) throws AirlineException;
	public List<FlightInfoBean> viewFlightScheduleDestCity(String destCity) throws AirlineException;
	public List<FlightInfoBean> viewFlightScheduleSrcCity(String srcCity) throws AirlineException;
	public List<FlightInfoBean> viewFlightScheduleDeptDate(String deptDate) throws AirlineException;
	public List<FlightInfoBean> viewFlightScheduleArrDate(String arrDate) throws AirlineException;
	public List<String> getFlightNoList() throws AirlineException;
	public boolean updateFlightDetails(FlightInfoBean flight) throws AirlineException;
	public boolean updateFlightSeats(String bookingId) throws AirlineException;

}