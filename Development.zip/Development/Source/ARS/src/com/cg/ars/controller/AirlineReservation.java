package com.cg.ars.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ars.bean.BookingInfoBean;
import com.cg.ars.bean.CustomerBean;
import com.cg.ars.bean.FlightInfoBean;
import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.service.AirlineServiceImpl;

/**
 * Servlet implementation class AirlineReservation
 */
@WebServlet(name="/AirlineReservation",
			urlPatterns ={"/AirlineReservation", "/AuthorityLoginPage", "/AuthorityLogin", "/PassengerLogin", "/PassengerLoginPage", 
							"/PassengerSignUp", "/SignUpFirst", "/SignUpNext", "/PassengerBookingEntry", "/PassengerBooking", 
							"/BookFlight", "/BookingPayment", "/ViewCustomerBooking", "/CustomerHomePage", "/DeleteCustomerBooking",
							"/DeleteCustomerBookingId", "/LogOut", "/ViewFlightOccupancyDate", "/ViewOccupancyDate", "/InsertFlight",
							"/ExecutiveHomePage", "/ViewFlightOccupancyCity", "/ViewOccupancyCity", "/UpdateFlightInfo", "/ViewAllFlights",
							"/InsertFlightDetails", "/AdminHomePage", "/RemoveFlight", "/FlightRemoval", "/UpdateFlightSchedule", 
							"/ViewFlightSchedule", "/ViewParticularFlight", "/FlightIdSchedule", "/GenerateReports", "/FlightListReportDestCity",
							"/PassengerListReportId", "/PassengerListReport", "/BookingListReportId", "/BookingListReport", "/DestCityReport",
							"/FlightListReportSrcCity", "/SrcCityReport", "/FlightListReportDeptDate", "/DeptDateReport", "/FlightListReportArrDate",
							"/ArrDateReport", "/ChangeFlightSchedule", "/EditFlightSchedule", "/UpdateFlightDetails"})

public class AirlineReservation extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AirlineReservation() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		String targetPath = null;
		RequestDispatcher reqDispatch;
			
 		
		if("/AirlineReservation".equalsIgnoreCase(path))
		{
			targetPath = "/pages/home.jsp";
		}
		
		if("/AdminHomePage".equalsIgnoreCase(path))
		{
			targetPath = "/pages/adminPage.jsp";
		}
		
		if("/ExecutiveHomePage".equalsIgnoreCase(path))
		{
			targetPath = "/pages/executivePage.jsp";
		}
		
		if("/CustomerHomePage".equalsIgnoreCase(path))
		{
			targetPath = "/pages/customerPage.jsp";
		}
		
		if("/AuthorityLoginPage".equalsIgnoreCase(path))
		{
			targetPath = "/pages/authorityLogin.jsp";
		}
		
		if("/PassengerLoginPage".equalsIgnoreCase(path))
		{
			targetPath = "/pages/passengerLogin.jsp";
		}
		
		if("/LogOut".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/PassengerSignUp".equalsIgnoreCase(path))
		{
			targetPath = "/pages/signUp1.jsp";
		}
		
		if("/PassengerBookingEntry".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/ViewCustomerBooking".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/DeleteCustomerBooking".equalsIgnoreCase(path))
		{
			targetPath = "/pages/bookingIdAccept.jsp";
		}
		
		if("/ViewFlightOccupancyDate".equalsIgnoreCase(path))
		{
			targetPath = "/pages/flightOccupancyDate.jsp";
		}
				
		if("/ViewFlightOccupancyCity".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/UpdateFlightInfo".equalsIgnoreCase(path))
		{
			targetPath = "/pages/updatePage.jsp";
		}
		
		if("/InsertFlight".equalsIgnoreCase(path))
		{
			targetPath = "/pages/insertFlightDetails.jsp";
		}
		
		if("/RemoveFlight".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/UpdateFlightSchedule".equalsIgnoreCase(path))
		{
			targetPath = "/pages/manageFlightSchedule.jsp";
		}
		
		if("/ViewFlightSchedule".equalsIgnoreCase(path))
		{
			targetPath = "/pages/viewScheduleOptions.jsp";
		}
		
		if("/ViewAllFlights".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/ViewParticularFlight".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/GenerateReports".equalsIgnoreCase(path))
		{
			targetPath = "/pages/generateReportOptions.jsp";
		}
		
		if("/PassengerListReportId".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/BookingListReportId".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/FlightListReportDestCity".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/FlightListReportSrcCity".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		if("/FlightListReportDeptDate".equalsIgnoreCase(path))
		{
			targetPath = "/pages/chooseDeptDate.jsp";
		}
		
		if("/FlightListReportArrDate".equalsIgnoreCase(path))
		{
			targetPath = "/pages/chooseArrDate.jsp";
		}
		
		if("/ChangeFlightSchedule".equalsIgnoreCase(path))
		{
			doPost(request, response);
		}
		
		reqDispatch = getServletContext().getRequestDispatcher(targetPath);
		reqDispatch.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path = request.getServletPath();
		System.out.println(path);
		String targetPath = null;
		RequestDispatcher reqDispatch;
		UserBean userObj;
		FlightInfoBean flightObj;
		CustomerBean customerObj;
		BookingInfoBean bookObj;
		AirlineServiceImpl service;
		HttpSession session = request.getSession();
		
		
		//To check admin or airline executive login credentials
		if("/AuthorityLogin".equalsIgnoreCase(path))
		{
			userObj = new UserBean();
			userObj.setUserName(request.getParameter("username").trim());
			userObj.setPassword(request.getParameter("password").trim());
			System.out.println(request.getParameter("role"));
			userObj.setRole(request.getParameter("role"));
			service = new AirlineServiceImpl();
			
			try 
			{
				if(service.isValidAuthority(userObj))
				{
					session.setAttribute("username", userObj.getUserName());
					if(userObj.getRole().equals("administrator"))
						targetPath = "/pages/adminPage.jsp";
					else
						targetPath = "/pages/executivePage.jsp";
				}
					
				else
				{
					request.setAttribute("authorityLoginFailed", "Invalid login credentials");
					targetPath = "/pages/authorityLogin.jsp";
				}
						
			}
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
				
		}
		
		
		//To check passenger login credentials
		if("/PassengerLogin".equalsIgnoreCase(path))
		{
			userObj = new UserBean();
			userObj.setUserName(request.getParameter("username"));
			userObj.setPassword(request.getParameter("password"));
			service = new AirlineServiceImpl();
			
			try 
			{
				if(service.isValidUser(userObj))
				{
					targetPath = "/pages/customerPage.jsp";
					session.setAttribute("username", userObj.getUserName());
				}
				else
				{
					request.setAttribute("passengerLoginFailed", "Invalid login credentials");
					targetPath = "/pages/passengerLogin.jsp";
				}
						
			}
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		
		//first sign up page for passenger to check if desired username is available
		if("/SignUpFirst".equalsIgnoreCase(path))
		{
			customerObj = new CustomerBean();
			customerObj.setFirstName(request.getParameter("fName"));
			customerObj.setLastName(request.getParameter("lName"));
			customerObj.setUserName(request.getParameter("username"));
			customerObj.setEmail(request.getParameter("email"));
			customerObj.setPhoneNo(Long.parseLong(request.getParameter("phoneNo")));
			session.setAttribute("customerObj", customerObj);
			service = new AirlineServiceImpl();
			
			try 
			{
				if(service.isAvailableUsername(customerObj))
				{
					session.setAttribute("username", customerObj.getUserName());
					session.setAttribute("phoneNo", customerObj.getPhoneNo());
					targetPath = "/pages/signUp2.jsp";
				}
				else
				{
					request.setAttribute("usernameTaken", "User name is already used");
					targetPath = "/pages/signUp1.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/SignUpNext".equalsIgnoreCase(path))
		{
			userObj = new UserBean();
			userObj.setUserName((String)session.getAttribute("username"));
			userObj.setPassword(request.getParameter("password"));
			userObj.setMobileNo((Long)session.getAttribute("phoneNo"));
			String password = request.getParameter("re-password");
			
			if(!userObj.getPassword().equals(password))
			{
				request.setAttribute("passwordMismatch", "Passwords don't match");
				targetPath = "/pages/signUp2.jsp";
			}
			else
			{
				service = new AirlineServiceImpl();
				customerObj = (CustomerBean) session.getAttribute("customerObj");
				try 
				{
					
					if(service.addNewPassenger(customerObj, userObj))
					{
						targetPath = "/pages/customerPage.jsp";
						session.setAttribute("username", userObj.getUserName());
					}
				}
				catch (AirlineException e) 
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}		
		}
		
		if("/PassengerBookingEntry".equalsIgnoreCase(path))
		{
			if(session.getAttribute("username")==null)
			{
				request.setAttribute("signUpBeforeBooking", "Please sign-up or login before booking.");
				targetPath = "/pages/signUp1.jsp";
			}
			else
			{
				service = new AirlineServiceImpl();
				List<String> deptCityList = new ArrayList<String>();
				List<String> arrCityList = new ArrayList<String>();
				try 
				{
					deptCityList = service.findDepartureCities();
					session.setAttribute("deptCityList", deptCityList);
					arrCityList = service.findArrivalCities();
					session.setAttribute("arrCityList", arrCityList);
					targetPath = "/pages/bookingOptionsPage.jsp";
				}
				catch (AirlineException e)
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}
		}
		
		if("/PassengerBooking".equalsIgnoreCase(path))
		{
			flightObj = new FlightInfoBean();
			
			String deptCity = request.getParameter("deptCity");
			String arrCity = request.getParameter("arrCity");
			String deptDate = request.getParameter("deptDate");
						
			if(deptCity.equals(arrCity))
			{
				request.setAttribute("deptArrCity", "Departure and arrival cities are the same.");
				targetPath = "/pages/bookingOptionsPage.jsp";
			}
			else
			{
				session.setAttribute("deptCity", deptCity);
				session.setAttribute("arrCity", arrCity);
				List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
				service = new AirlineServiceImpl();
				
				try 
				{
					flightList = service.searchFlightDetails(deptCity, arrCity, deptDate);
					if(flightList.isEmpty())
					{
						request.setAttribute("noFlights", "No Flights Available. Try again.");
						targetPath = "/pages/bookingOptionsPage.jsp";
					}
					else
					{
						session.setAttribute("searchFlightList", flightList);
						targetPath = "/pages/bookingPage.jsp";
					}
				} 
				catch (AirlineException e)
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}	
		}
		
		if("/BookFlight".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			String seatType = request.getParameter("seatType");
			String seatNum = request.getParameter("seatNum");

			service = new AirlineServiceImpl();
		
			try
			{
				if(service.isSeatAvailable(flightNo, seatType, seatNum))
				{
					bookObj = new BookingInfoBean();
					bookObj.setFlightNo(flightNo);
					bookObj.setClassType(seatType);
					bookObj.setNumPassenger(seatNum);
					bookObj.setSrcCity((String)session.getAttribute("deptCity"));
					bookObj.setDestCity((String)session.getAttribute("arrCity"));
					
					String username = (String) session.getAttribute("username");
					String emailId = service.getCustomerMail(username);
					bookObj.setCustMail(emailId);
					
					String custName = service.getCustomerName(username);
					bookObj.setCustName(custName);
					
					String totalFare = service.getTotalFare(flightNo, seatType, seatNum);
					bookObj.setTotalFare(totalFare);
					
					session.setAttribute("bookObj", bookObj);
					
					targetPath = "/pages/bookingPayment.jsp";
					
				}
				else
				{
					request.setAttribute("unavailableSeats", "Seats are unavailable. Try again");
					targetPath = "/pages/bookingPage.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
			
		}
		
		if("/BookingPayment".equalsIgnoreCase(path))
		{
			bookObj = (BookingInfoBean) session.getAttribute("bookObj");
			bookObj.setCreditCardInfo(request.getParameter("creditInfo"));
			service = new AirlineServiceImpl();
			
			try 
			{
				//System.out.println(boo)
				int bookingId = service.bookFlight(bookObj);
				System.out.println(bookingId);
				session.setAttribute("bookingId", bookingId);
				service.updateSeatNum(bookObj);
				targetPath = "/pages/bookingIdDisplay.jsp";
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
			
		}
		
		if("/ViewCustomerBooking".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<BookingInfoBean> bookingInfoList;
			String username = (String) session.getAttribute("username");
			
			try 
			{
				bookingInfoList = service.getCustomerBookingInfo(username);
				System.out.println(bookingInfoList.isEmpty());
				if(!bookingInfoList.isEmpty())
				{
					session.setAttribute("bookingInfoList", bookingInfoList);
					targetPath = "/pages/bookingInfoPage.jsp";
				}
				else
				{
					request.setAttribute("noBooking", "You haven't booked any flight yet.");
					targetPath = "/pages/customerPage.jsp";
				}
				
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.pages";
			}
		}
		
		if("/DeleteCustomerBookingId".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			String username = (String) session.getAttribute("username");
			String bookingId = request.getParameter("bookingId");
			
			try 
			{
				if(service.isValidBookingId(bookingId, username))
				{	
					if(service.updateFlightSeats(bookingId))
					{
						if(service.deleteCustomerBooking(bookingId))
						{
							request.setAttribute("successfulDelete", "Booking successfully deleted.");
							targetPath = "/pages/customerPage.jsp";
						}
					}
					else
					{
						request.setAttribute("updationError", "Error while updating your request. Try again.");
						targetPath = "/pages/bookingIdAccept.jsp";
					}
				}
				else
				{
					request.setAttribute("invalidBookingId", "Invalid Booking Id. Please try again.");
					targetPath = "/pages/bookingIdAccept.jsp";
				}
			}
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
			
		}
		
		if("/LogOut".equalsIgnoreCase(path))
		{
			session.removeAttribute("username");
			targetPath = "/pages/home.jsp";
		}
		
		if(("/ViewOccupancyDate").equalsIgnoreCase(path))
		{
			String deptDate = request.getParameter("deptDate");
			String arrDate = request.getParameter("arrDate");
			List<String> flightNoList = new ArrayList<String>();
			List<BookingInfoBean> occupancyList = new ArrayList<BookingInfoBean>();
			service = new AirlineServiceImpl();
			
			if(deptDate.compareTo(arrDate) <= 0)
			{
				try 
				{
					flightNoList = service.flightNoListDate(deptDate, arrDate);
					if(flightNoList.isEmpty())
					{
						request.setAttribute("noFlightsAvailable", "No flights available. Please try again.");
						targetPath = "/pages/flightOccupancyDate.jsp";
					}
					else
					{
						occupancyList = service.viewFlightOccupancy(flightNoList);
						if(occupancyList.isEmpty())
						{
							request.setAttribute("noFlightsBooked", "No flights booked. Please try again.");
							targetPath = "/pages/flightOccupancyDate.jsp";
						}
						else
						{
							request.setAttribute("occupancyList", occupancyList);
							targetPath = "/pages/flightOccupancyPage.jsp";
						}
					}
				} 
				catch (AirlineException e) 
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}
			else
			{
				request.setAttribute("deptGreaterThanArr", "Departure date cannot be greater than arrival date");
				targetPath = "/pages/flightOccupancyDate.jsp";
			}
		}
		
		if("/ViewFlightOccupancyCity".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<String> deptCityList = new ArrayList<String>();
			List<String> arrCityList = new ArrayList<String>();
			try 
			{
				deptCityList = service.findDepartureCities();
				session.setAttribute("deptCityList", deptCityList);
				arrCityList = service.findArrivalCities();
				session.setAttribute("arrCityList", arrCityList);
				targetPath = "/pages/flightOccupancyCity.jsp";
			}
			catch(AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/ViewOccupancyCity".equalsIgnoreCase(path))
		{
			String srcCity = request.getParameter("deptCity");
			String destCity = request.getParameter("arrCity");
			service = new AirlineServiceImpl();
			List<String> flightNoList = new ArrayList<String>();
			List<BookingInfoBean> occupancyList = new ArrayList<BookingInfoBean>();
			
			if(!srcCity.equals(destCity))
			{
				try 
				{
					flightNoList = service.flightNoListCity(srcCity, destCity);
					if(flightNoList.isEmpty())
					{
						request.setAttribute("noFlightsAvailable", "No flights available. Please try again.");
						targetPath = "/pages/flightOccupancyCity.jsp";
					}
					else
					{
						occupancyList = service.viewFlightOccupancy(flightNoList);
						if(occupancyList.isEmpty())
						{
							request.setAttribute("noFlightsBooked", "No flights booked. Please try again.");
							targetPath = "/pages/flightOccupancyCity.jsp";
						}
						else
						{
							request.setAttribute("occupancyList", occupancyList);
							targetPath = "/pages/flightOccupancyPage.jsp";
						}
					}
				} 
				catch (AirlineException e) 
				{
					request.setAttribute("error", e.getMessage());
					targetPath = "/pages/error.jsp";
				}
			}
			else
			{
				request.setAttribute("srcDestCity", "Source and destination cities can not be same.");
				targetPath = "/pages/flightOccupancyCity.jsp";
			}
			
		}
		
		if("/InsertFlightDetails".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			String flightNo = request.getParameter("flightNo");
			String flightName = request.getParameter("flightName");
			String deptCity = request.getParameter("deptCity");
			String arrCity = request.getParameter("arrCity");
			String deptDate = request.getParameter("deptDate");
			String arrDate = request.getParameter("arrDate");
					
			String hours, minutes, seconds;
			hours = request.getParameter("deptTimeHr");
			minutes = request.getParameter("deptTimeMin");
			seconds = request.getParameter("deptTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String deptTime = hours+":"+minutes+":"+seconds;
			
			hours = request.getParameter("arrTimeHr");
			minutes = request.getParameter("arrTimeMin");
			seconds = request.getParameter("arrTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String arrTime = hours+":"+minutes+":"+seconds;
						
			String firstClassSeats = request.getParameter("firstClassSeats");
			String firstClassFare = request.getParameter("firstClassFare");
			String businessClassSeats = request.getParameter("businessClassSeats");
			String businessClassFare = request.getParameter("businessClassFare");
			
			try 
			{
				if(service.isAvailableFlightNo(flightNo))
				{
					request.setAttribute("flightExists", "Flight already exists. Try again.");
					targetPath = "/pages/insertFlightDetails.jsp";
				}
				else if(deptCity.equals(arrCity))
				{
					request.setAttribute("srcDestCityEqual", "Source and destination cities cannot be equal. Try again.");
					targetPath = "/pages/insertFlightDetails.jsp";
				}
				else if(deptDate.compareTo(arrDate) > 0)
				{
					request.setAttribute("deptGreaterThanArrDate", "Departure date cannot be greater than arrival date");
					targetPath = "/pages/insertFlightDetails.jsp";
				}
				else if((deptDate.compareTo(arrDate) == 0) && (deptTime.compareTo(arrTime) >= 0))
				{
					request.setAttribute("deptGreaterThanArrTime", "Departure time cannot be greater than or equal to arrival time");
					targetPath = "/pages/insertFlightDetails.jsp";
				}
				else
				{
					deptTime = deptDate+" "+deptTime;
					arrTime = arrDate+" "+arrTime;
					
					flightObj = new FlightInfoBean();
					
					flightObj.setFlightNo(flightNo);
					flightObj.setAirline(flightName);
					flightObj.setDeptCity(deptCity);
					flightObj.setArrCity(arrCity);
					flightObj.setDeptDate(deptDate);
					flightObj.setArrDate(arrDate);
					flightObj.setDeptTime(deptTime);
					flightObj.setArrTime(arrTime);
					flightObj.setFirstSeats(Integer.parseInt(firstClassSeats));
					flightObj.setFirstSeatFare(Float.parseFloat(firstClassFare));
					flightObj.setBussSeats(Integer.parseInt(businessClassSeats));
					flightObj.setBussSeatFare(Float.parseFloat(businessClassFare));
						
					if(service.insertFlightDetails(flightObj))
					{
						request.setAttribute("flightObj", flightObj);
						targetPath = "/pages/displayFlightDetails.jsp";
					}
					else
					{
						request.setAttribute("insertError", "Error while inserting details. Try again.");
						targetPath = "/pages/insertFlightDetails.jsp";
					}
				}
			}
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/RemoveFlight".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/updatePage.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdToRemove.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/FlightRemoval".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
			
			try 
			{
				if(service.deleteFlightDetails(flightNo))
					{
						request.setAttribute("flightDeletedSuccessfully", "Flight "+flightNo+" deleted successfully.");
						targetPath = "/pages/adminPage.jsp";
					}
					else
					{
						request.setAttribute("flightNotDeleted", "Could not delete the flight "+flightNo);
						targetPath = "/pages/adminPage.jsp";
					}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/ViewAllFlights".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<FlightInfoBean> flightScheduleList = new ArrayList<FlightInfoBean>();
			
			try 
			{
				flightScheduleList = service.viewAllFlightSchedules();
			
				if(flightScheduleList.isEmpty())
				{
					request.setAttribute("noFlightSchedules", "No Flights Available. Try again.");
					targetPath = "/pages/viewScheduleOptions.jsp";
				}
				else
				{
					request.setAttribute("flightScheduleList", flightScheduleList);
					targetPath = "/pages/allFlightSchedules.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
			
		}
		
		if("/ViewParticularFlight".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/viewScheduleOptions.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdForSchedule.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/FlightIdSchedule".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				flightObj = new FlightInfoBean();
				flightObj = service.viewFlightSchedule(flightNo);
				request.setAttribute("flightObj", flightObj);
				targetPath = "/pages/flightScheduleOnId.jsp";
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/PassengerListReportId".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/generateReportOptions.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdForReport1.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/PassengerListReport".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				List<CustomerBean> passengerList = new ArrayList<CustomerBean>();
				passengerList = service.getPassengerList(flightNo);
					
				if(passengerList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked in the flight "+flightNo);
					targetPath = "/pages/flightIdForReport1.jsp";
				}
				else
				{
					request.setAttribute("flightNo", flightNo);
					request.setAttribute("passengerList", passengerList);
					targetPath = "/pages/passengerListReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/BookingListReportId".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/generateReportOptions.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdForReport2.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/BookingListReport".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				List<BookingInfoBean> bookingList = new ArrayList<BookingInfoBean>();
				bookingList = service.getBookingList(flightNo);
				
				if(bookingList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked in the flight "+flightNo);
					targetPath = "/pages/flightIdForReport2.jsp";
				}
				else
				{
					request.setAttribute("flightNo", flightNo);
					request.setAttribute("bookingList", bookingList);
					targetPath = "/pages/bookingListReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/FlightListReportDestCity".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<String> destCityList = new ArrayList<String>();
			try 
			{
				destCityList = service.findArrivalCities();
				if(destCityList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights to show");
					targetPath = "/pages/generateReportOptions.jsp";
				}
				else
				{
					request.setAttribute("destCityList", destCityList);
					targetPath = "/pages/chooseDestCity.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/DestCityReport".equalsIgnoreCase(path))
		{
			String destCity = request.getParameter("destCity");
			service = new AirlineServiceImpl();
			List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
			
			try 
			{
				flightList = service.viewFlightScheduleDestCity(destCity);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked to the destination city "+destCity);
					targetPath = "/pages/chooseDestCity.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightDetailsReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		
		if("/FlightListReportSrcCity".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			List<String> srcCityList = new ArrayList<String>();
			
			try 
			{
				srcCityList = service.findDepartureCities();
				if(srcCityList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights to show");
					targetPath = "/pages/generateReportOptions.jsp";
				}
				else
				{
					request.setAttribute("srcCityList", srcCityList);
					targetPath = "/pages/chooseSourceCity.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/SrcCityReport".equalsIgnoreCase(path))
		{
			String srcCity = request.getParameter("srcCityList");
			service = new AirlineServiceImpl();
			List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
			
			try 
			{
				flightList = service.viewFlightScheduleSrcCity(srcCity);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlightsBooked", "No flights have been booked from the source city "+srcCity);
					targetPath = "/pages/chooseSourceCity.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightDetailsReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		
		if("/DeptDateReport".equalsIgnoreCase(path))
		{
			String deptDate = request.getParameter("deptDate");
			service = new AirlineServiceImpl();
			List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
			
			try 
			{
				flightList = service.viewFlightScheduleDeptDate(deptDate);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights available on the date "+deptDate);
					targetPath = "/pages/chooseDeptDate.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightDetailsReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		
		if("/ArrDateReport".equalsIgnoreCase(path))
		{
			String arrDate = request.getParameter("arrDate");
			service = new AirlineServiceImpl();
			List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
			
			try 
			{
				flightList = service.viewFlightScheduleArrDate(arrDate);
				if(flightList.isEmpty())
				{
					request.setAttribute("noFlights", "No flights available on the date "+arrDate);
					targetPath = "/pages/chooseArrDate.jsp";
				}
				else
				{
					request.setAttribute("flightList", flightList);
					targetPath = "/pages/flightDetailsReport.jsp";
				}
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}	
		}
		
		if("/ChangeFlightSchedule".equalsIgnoreCase(path))
		{
			List<String> flightNoList = new ArrayList<String>();
			service = new AirlineServiceImpl();
			
			try 
			{
				flightNoList = service.getFlightNoList();
				if(flightNoList.isEmpty())
				{
					request.setAttribute("noFlightsAvailable", "No flights are available");
					targetPath = "/pages/manageFlightSchedule.jsp";
				}
				else
				{
					session.setAttribute("flightNoList", flightNoList);
					targetPath = "/pages/flightIdToUpdate.jsp";
				}
			} 
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/EditFlightSchedule".equalsIgnoreCase(path))
		{
			String flightNo = request.getParameter("flightNo");
			service = new AirlineServiceImpl();
					
			try 
			{
				flightObj = new FlightInfoBean();
				flightObj = service.viewFlightSchedule(flightNo);
					
				session.setAttribute("flightObj", flightObj);
				targetPath = "/pages/editFlightDetails.jsp";
				
			} 
			catch (AirlineException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		if("/UpdateFlightDetails".equalsIgnoreCase(path))
		{
			service = new AirlineServiceImpl();
			String flightNo = request.getParameter("flightNo");
			String flightName = request.getParameter("flightName");
			String deptCity = request.getParameter("deptCity");
			String arrCity = request.getParameter("arrCity");
			String deptDate = request.getParameter("deptDate");
			String arrDate = request.getParameter("arrDate");

			String hours, minutes, seconds;
			hours = request.getParameter("deptTimeHr");
			minutes = request.getParameter("deptTimeMin");
			seconds = request.getParameter("deptTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String deptTime = hours+":"+minutes+":"+seconds;
			
			hours = request.getParameter("arrTimeHr");
			minutes = request.getParameter("arrTimeMin");
			seconds = request.getParameter("arrTimeSec");
			if(hours.length() == 1)
				hours = "0"+hours;
			if(minutes.length() == 1)
				minutes = "0"+minutes;
			if(seconds.length() == 1)
				seconds = "0"+seconds;
			String arrTime = hours+":"+minutes+":"+seconds;
			
			String firstClassSeats = request.getParameter("firstClassSeats");
			String firstClassFare = request.getParameter("firstClassFare");
			String businessClassSeats = request.getParameter("businessClassSeats");
			String businessClassFare = request.getParameter("businessClassFare");
			
			try 
			{
				if(deptCity.equals(arrCity))
				{
					request.setAttribute("srcDestCityEqual", "Source and destination cities cannot be equal. Try again.");
					targetPath = "/pages/editFlightDetails.jsp";
				}
				else if(deptDate.compareTo(arrDate) > 0)
				{
					request.setAttribute("deptGreaterThanArrDate", "Departure date cannot be greater than arrival date");
					targetPath = "/pages/editFlightDetails.jsp";
				}
				else if((deptDate.compareTo(arrDate) == 0) && (deptTime.compareTo(arrTime) >= 0))
				{
					request.setAttribute("deptGreaterThanArrTime", "Departure time cannot be greater than or equal to arrival time");
					targetPath = "/pages/editFlightDetails.jsp";
				}
				else
				{
					deptTime = deptDate+" "+deptTime;
					arrTime = arrDate+" "+arrTime;
					
					flightObj = new FlightInfoBean();
					
					flightObj.setFlightNo(flightNo);
					flightObj.setAirline(flightName);
					flightObj.setDeptCity(deptCity);
					flightObj.setArrCity(arrCity);
					flightObj.setDeptDate(deptDate);
					flightObj.setArrDate(arrDate);
					flightObj.setDeptTime(deptTime);
					flightObj.setArrTime(arrTime);
					flightObj.setFirstSeats(Integer.parseInt(firstClassSeats));
					flightObj.setFirstSeatFare(Float.parseFloat(firstClassFare));
					flightObj.setBussSeats(Integer.parseInt(businessClassSeats));
					flightObj.setBussSeatFare(Float.parseFloat(businessClassFare));
						
					if(service.updateFlightDetails(flightObj))
					{
						request.setAttribute("flightObj", flightObj);
						targetPath = "/pages/displayFlightDetails.jsp";
					}
					else
					{
						request.setAttribute("updateError", "Error while updating details. Try again.");
						targetPath = "/pages/editFlightDetails.jsp";
					}
				}
			}
			catch (AirlineException e)
			{
				request.setAttribute("error", e.getMessage());
				targetPath = "/pages/error.jsp";
			}
		}
		
		reqDispatch = getServletContext().getRequestDispatcher(targetPath);
		reqDispatch.forward(request, response);
	}

}
