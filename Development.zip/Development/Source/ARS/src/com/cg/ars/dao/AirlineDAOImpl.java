package com.cg.ars.dao;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.bean.BookingInfoBean;
import com.cg.ars.bean.CustomerBean;
import com.cg.ars.bean.FlightInfoBean;
import com.cg.ars.bean.UserBean;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.util.ConvertToSQLDate;
import com.cg.ars.util.DBUtil;

public class AirlineDAOImpl implements IAirlineDAO {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rset;
	
	@Override
	public boolean isValidAuthority(UserBean user) throws AirlineException {

		conn = DBUtil.getConnection();
		String password, role;
		boolean validAuthority = false;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			System.out.println(user.getUserName());
			pstmt = conn.prepareStatement(IQueryMapper.USER_PASSWORD_ROLE);
			pstmt.setString(1, user.getUserName());
			rset = pstmt.executeQuery();
			System.out.println(rset.next());
			System.out.println(rset.getString(1));
			System.out.println(rset.getString(2));
			System.out.println(user.getPassword());
			System.out.println(user.getRole());
			while(rset.next())
			{
				
				password = rset.getString(1);
				role = rset.getString(2);
				System.out.println(password);
				System.out.println(role);
				if((password.equals(user.getPassword())) && (role.equals(user.getRole())))
					validAuthority = true;
				
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		System.out.println(validAuthority);
		return validAuthority;
	}
	
	@Override
	public boolean isValidUser(UserBean user) throws AirlineException {

		conn = DBUtil.getConnection();
		String password;
		boolean validUser = false;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.USER_PASSWORD);
			pstmt.setString(1, user.getUserName());
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				password = rset.getString(1);
				if(password.equals(user.getPassword()))
					validUser = true;
				
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return validUser;
	}

	@Override
	public boolean isAvailableUsername(CustomerBean customer) throws AirlineException {
		
		conn = DBUtil.getConnection();
		String username = customer.getUserName();
		boolean validUsername = true;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.USERNAME_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				if(username.equals(rset.getString(1)))
					validUsername = false;
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return validUsername;
	}

	@Override
	public boolean addNewPassenger(CustomerBean customer, UserBean user) throws AirlineException {
		
		conn = DBUtil.getConnection();
		
		int record = 0;
		boolean recordInserted = false;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.REGISTER_CUSTOMER);
			pstmt.setString(1, customer.getFirstName());
			pstmt.setString(2, customer.getLastName());
			pstmt.setString(3, customer.getUserName());
			pstmt.setString(4, customer.getEmail());
			pstmt.setLong(5, customer.getPhoneNo());
			pstmt.executeUpdate();
			
			pstmt = conn.prepareStatement(IQueryMapper.ADD_NEW_USER);
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, Long.toString(user.getMobileNo()));
			record = pstmt.executeUpdate();
			
			if(record > 0)
				recordInserted = true;
			
			conn.commit();
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return recordInserted;
	}

	@Override
	public List<String> findDepartureCities() throws AirlineException {
		
		conn = DBUtil.getConnection();
		
		List<String> deptCityList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.DEPARTURE_CITY_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				deptCityList.add(rset.getString(1));
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return deptCityList;
	}

	@Override
	public List<String> findArrivalCities() throws AirlineException {

		conn = DBUtil.getConnection();
		
		List<String> arrCityList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.ARRIVAL_CITY_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				arrCityList.add(rset.getString(1));
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return arrCityList;
	}

	@Override
	public List<FlightInfoBean> searchFlightDetails(String deptCity, String arrCity, String deptDate) throws AirlineException {
		
		conn = DBUtil.getConnection();
		
		List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.SEARCH_FLIGHT_DETAILS);
			pstmt.setString(1, deptCity);
			pstmt.setString(2, arrCity);
			pstmt.setDate(3, ConvertToSQLDate.convertDate(deptDate));
			rset = pstmt.executeQuery();
			
			FlightInfoBean flight;
			
			while(rset.next())
			{
				flight = new FlightInfoBean();
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(deptCity);
				flight.setArrCity(arrCity);
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7));
				flight.setArrTime(rset.getString(8));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}
	
	@Override
	public boolean isSeatAvailable(String flightNo, String seatType, String seatNum) throws AirlineException {
		
		conn = DBUtil.getConnection();
		boolean seatAvailable = false;
		int availableSeats = 0;
		int seatNo=Integer.parseInt(seatNum);
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
		
			pstmt = conn.prepareStatement(IQueryMapper.SEAT_NUMBERS);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(seatType.equals("First Class"))
					availableSeats = rset.getInt(1);
				else
					availableSeats = rset.getInt(2);
			}
			if(availableSeats >= seatNo)
				seatAvailable = true;

		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return seatAvailable;
	}
	
	@Override
	public String getCustomerMail(String username) throws AirlineException {
		
		conn = DBUtil.getConnection();
		String emailId = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
				pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_MAIL);
				pstmt.setString(1, username);
				rset = pstmt.executeQuery();
				
				if(rset.next())
					emailId = rset.getString(1);
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return emailId;
	}
	
	@Override
	public String getCustomerName(String username) throws AirlineException {
		
		conn = DBUtil.getConnection();
		String custName = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
				pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_NAME);
				pstmt.setString(1, username);
				rset = pstmt.executeQuery();
				
				if(rset.next())
				{
					String firstName = rset.getString(1);
					String lastName = rset.getString(2);
					custName = firstName +" "+ lastName;
				}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return custName;
	}
	
	@Override
	public String getTotalFare(String flightNo, String seatType, String seatNum) throws AirlineException {

		conn = DBUtil.getConnection();
		int totalFare = 0;
		int farePerSeat = 0;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			if(seatType.equals("First Class"))
				pstmt = conn.prepareStatement(IQueryMapper.FIRST_CLASS_FARE);
			else
				pstmt = conn.prepareStatement(IQueryMapper.BUSINESS_CLASS_FARE);
			
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
				farePerSeat =rset.getInt(1);
			
			totalFare = farePerSeat * Integer.parseInt(seatNum);
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return Integer.toString(totalFare);
	}

	@Override
	public int bookFlight(BookingInfoBean book) throws AirlineException {
		
		conn = DBUtil.getConnection();
		int bookingId=0 ;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOK_FLIGHT);
			//pstmt.setString(1, book.getBookingId());
			/*System.out.println(book.getCustMail());
			System.out.println(book.getCustName());
			System.out.println(book.getCustName());
			System.out.println(book.getNumPassenger());
			System.out.println(book.getClassType());
			System.out.println(book.getTotalFare());
			System.out.println(book.getCreditCardInfo());
			System.out.println(book.getSrcCity());
			System.out.println(book.getDestCity());
			System.out.println(book.getFlightNo());
			String query = "select booking_id_seq.NEXTVAL from dual";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next())
			{
				book.setBookingId(rs.getString(1));
			}
			System.out.println(book.getBookingId());*/
			//pstmt.setString(1, book.getBookingId());
			pstmt.setString(1, book.getCustMail());
			pstmt.setString(2, book.getCustName());
			pstmt.setString(3,book.getNumPassenger());
			pstmt.setString(4, book.getClassType());
			pstmt.setString(5,book.getTotalFare());
			pstmt.setString(6, book.getCreditCardInfo());
			pstmt.setString(7, book.getSrcCity());
			pstmt.setString(8, book.getDestCity());
			pstmt.setString(9,book.getFlightNo());
			int record = pstmt.executeUpdate();
			//System.out.println("Hai");
			//System.out.println(record);
			/*String query1 = "insert into bookinginformation values(booking_id_seq.nextval,'book.getCustMail()','book.getCustName()','book.getNumPassenger()','book.getClassType()','book.getTotalFare()','book.getCreditCardInfo()','book.getSrcCity()','book.getDestCity()','book.getFlightNo()')";
			Statement st1 = conn.createStatement();
			st1.executeUpdate(query1);*/
			conn.commit();	
			//bookingId = booking_id_seq.currval;
			
			if(record == 1)
			{
				pstmt = conn.prepareStatement(IQueryMapper.BOOKING_ID);
				rset = pstmt.executeQuery();
				//System.out.println(rset.next());
				
				if(rset.next()==true)
				{
					//System.out.println(rset.getString(1));
					bookingId = Integer.parseInt(rset.getString(1));
				}
				
			}	
						
		}
		catch(SQLException e)
		{
			//throw new AirlineException("Technical Issue. Please try again.");
			e.printStackTrace();
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return bookingId;
	}

	@Override
	public boolean updateSeatNum(BookingInfoBean book) throws AirlineException {
		
		conn = DBUtil.getConnection();
		boolean updatedRecord = true;
		int availableSeats = 0, newAvailableSeats = 0;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
					
			pstmt = conn.prepareStatement(IQueryMapper.SEAT_NUMBERS);
			pstmt.setString(1, book.getFlightNo());
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(book.getClassType().equals("First Class"))
				{
					availableSeats = rset.getInt(1);
					pstmt = conn.prepareStatement(IQueryMapper.FIRST_CLASS_SEATS_REMAINING);
				}
				else
				{
					availableSeats = rset.getInt(2);
					pstmt = conn.prepareStatement(IQueryMapper.BUSINESS_CLASS_SEATS_REMAINING);
				}
			}
			newAvailableSeats = availableSeats - Integer.parseInt(book.getNumPassenger());
			pstmt.setInt(1, newAvailableSeats);
			pstmt.setString(2, book.getFlightNo());
			int record = pstmt.executeUpdate();
			
			if(record == 1)
				updatedRecord = true;
			
			conn.commit();				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return updatedRecord;
	}


	@Override
	public List<BookingInfoBean> getCustomerBookingInfo(String username) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<BookingInfoBean> bookingInfoList = new ArrayList<BookingInfoBean>();
		String custName = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_NAME);
			pstmt.setString(1, username);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				String firstName = rset.getString(1);
				String lastName = rset.getString(2);
				custName = firstName +" "+ lastName;
			}		
		
			pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_BOOKING_INFO);
			pstmt.setString(1, custName);
			rset = pstmt.executeQuery();
		
			BookingInfoBean bookingObj;
			
			while(rset.next())
			{
				bookingObj = new BookingInfoBean();
				bookingObj.setBookingId(rset.getString(1));
				bookingObj.setNumPassenger(rset.getString(2));
				bookingObj.setClassType(rset.getString(3));
				bookingObj.setTotalFare(rset.getString(4));
				bookingObj.setSrcCity(rset.getString(5));
				bookingObj.setDestCity(rset.getString(6));
				bookingObj.setFlightNo(rset.getString(7));
				
				bookingInfoList.add(bookingObj);
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return bookingInfoList;
	}
	
	 
	@Override
	public boolean isValidBookingId(String bookingId, String username) throws AirlineException {

		conn = DBUtil.getConnection();
		boolean validBookingId = false;
		String custName = null;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.CUSTOMER_NAME);
			pstmt.setString(1, username);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				String firstName = rset.getString(1);
				String lastName = rset.getString(2);
				custName = firstName +" "+ lastName;
			}		
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOKING_CUSTOMER_NAME);
			pstmt.setString(1, bookingId);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(rset.getString(1).equals(custName))
					validBookingId = true;
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return validBookingId;
	}

	@Override
	public boolean deleteCustomerBooking(String bookingId) throws AirlineException {

		conn = DBUtil.getConnection();
		boolean recordDeleted = false;
		int record = 0;
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.CUTOMER_DELETE_BOOKING);
			pstmt.setString(1, bookingId);
			record = pstmt.executeUpdate();
			
			if(record == 1)
			{
				recordDeleted = true;
			}
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordDeleted;
	}

	public List<String> flightNoListDate(String deptDate, String arrDate) throws AirlineException
	{
		conn = DBUtil.getConnection();
		List<String> flightNoList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST_DATE);
			pstmt.setDate(1, ConvertToSQLDate.convertDate(deptDate));
			pstmt.setDate(2, ConvertToSQLDate.convertDate(arrDate));
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				flightNoList.add(rset.getString(1));
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return flightNoList;
	}

	@Override
	public List<BookingInfoBean> viewFlightOccupancy(List<String> flightNoList) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<BookingInfoBean> occupancyList = new ArrayList<BookingInfoBean>();
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			BookingInfoBean bookObj = null;
			
			for(String flightNo : flightNoList)
			{
				int occupancy =0;
				
				pstmt = conn.prepareStatement(IQueryMapper.OCCUPANCY_COUNT);
				pstmt.setString(1, flightNo);
				rset = pstmt.executeQuery();
				
				while(rset.next())
				{
					occupancy += Integer.parseInt(rset.getString(1));
					
				}
			
				bookObj = new BookingInfoBean();
				bookObj.setFlightNo(flightNo);
				bookObj.setNumPassenger(Integer.toString(occupancy));
				
				occupancyList.add(bookObj);
			}
			
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return occupancyList;
	}

	@Override
	public List<String> flightNoListCity(String srcCity, String destCity) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<String> flightNoList = new ArrayList<String>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST_CITY);
			pstmt.setString(1, srcCity);
			pstmt.setString(2, destCity);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				flightNoList.add(rset.getString(1));
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return flightNoList;
	}

	@Override
	public boolean isAvailableFlightNo(String flightNo) throws AirlineException {

		conn = DBUtil.getConnection();
		boolean availableFlightNo = false;
						
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				if(flightNo.equals(rset.getString(1)))
					availableFlightNo = true;
			}
			
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return availableFlightNo;
	}

	@Override
	public boolean insertFlightDetails(FlightInfoBean flight) throws AirlineException {
		
		conn = DBUtil.getConnection();
		boolean recordInserted = false;
		int record;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.ADD_NEW_FLIGHT);
			
			pstmt.setString(1, flight.getFlightNo());
			pstmt.setString(2, flight.getAirline());
			pstmt.setString(3, flight.getDeptCity());
			pstmt.setString(4, flight.getArrCity());
			pstmt.setDate(5, ConvertToSQLDate.convertDate(flight.getDeptDate()));
			pstmt.setDate(6, ConvertToSQLDate.convertDate(flight.getArrDate()));
			pstmt.setTimestamp(7, Timestamp.valueOf(flight.getDeptTime()));
			pstmt.setTimestamp(8, Timestamp.valueOf(flight.getArrTime()));
			pstmt.setInt(9, flight.getFirstSeats());
			pstmt.setFloat(10, flight.getFirstSeatFare());
			pstmt.setInt(11, flight.getBussSeats());
			pstmt.setFloat(12, flight.getBussSeatFare());
			
			record = pstmt.executeUpdate();
			
			if(record == 1)
				recordInserted = true;
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordInserted;
	}

	@Override
	public boolean deleteFlightDetails(String flightNo) throws AirlineException {

		conn = DBUtil.getConnection();
		boolean recordDeleted = false;
		int record;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.DELETE_FLIGHT);
			pstmt.setString(1, flightNo);
			record = pstmt.executeUpdate();
			
			if(record == 1)
				recordDeleted = true;
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordDeleted;
	}

	@Override
	public List<FlightInfoBean> viewAllFlightSchedules() throws AirlineException {

		conn = DBUtil.getConnection();
		List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.ALL_FLIGHTS);
			rset = pstmt.executeQuery();
			
			FlightInfoBean flight;
			
			while(rset.next())
			{
				flight = new FlightInfoBean();
				
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public FlightInfoBean viewFlightSchedule(String flightNo) throws AirlineException {
		
		conn = DBUtil.getConnection();
		FlightInfoBean flight = new FlightInfoBean();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.VIEW_FLIGHTID_SCHEDULE);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));	
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flight;
	}

	@Override
	public List<CustomerBean> getPassengerList(String flightNo) throws AirlineException {

		conn = DBUtil.getConnection();
		List<CustomerBean> passengerList = new ArrayList<CustomerBean>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.PASSENGER_LIST);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			CustomerBean custObj;
			
			while(rset.next())
			{
				custObj = new CustomerBean();
				
				custObj.setFirstName(rset.getString(1));
				custObj.setLastName(rset.getString(2));
				custObj.setEmail(rset.getString(3));
				custObj.setPhoneNo(rset.getLong(4));
				
				passengerList.add(custObj);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return passengerList;
	}

	@Override
	public List<BookingInfoBean> getBookingList(String flightNo) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<BookingInfoBean> bookingList = new ArrayList<BookingInfoBean>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOKING_LIST);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			BookingInfoBean bookObj;
			
			while(rset.next())
			{
				bookObj = new BookingInfoBean();
				
				bookObj.setBookingId(rset.getString(1));
				bookObj.setCustName(rset.getString(2));
				bookObj.setNumPassenger(rset.getString(3));
				bookObj.setClassType(rset.getString(4));
				
				bookingList.add(bookObj);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return bookingList;
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleDestCity(String destCity) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_DEST_CITY);
			pstmt.setString(1, destCity);
			rset = pstmt.executeQuery();
			
			FlightInfoBean flight;
			
			while(rset.next())
			{
				flight = new FlightInfoBean();
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(destCity);
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7));
				flight.setArrTime(rset.getString(8));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleSrcCity(String srcCity) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_SRC_CITY);
			pstmt.setString(1, srcCity);
			rset = pstmt.executeQuery();
			
			FlightInfoBean flight;
			
			while(rset.next())
			{
				flight = new FlightInfoBean();
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(srcCity);
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleDeptDate(String deptDate) throws AirlineException {

		conn = DBUtil.getConnection();
		List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_DEPT_DATE);
			pstmt.setDate(1, ConvertToSQLDate.convertDate(deptDate));
			rset = pstmt.executeQuery();
			
			FlightInfoBean flight;
			
			while(rset.next())
			{
				flight = new FlightInfoBean();
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleArrDate(String arrDate) throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<FlightInfoBean> flightList = new ArrayList<FlightInfoBean>();
		
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_DETAILS_ARR_DATE);
			pstmt.setDate(1, ConvertToSQLDate.convertDate(arrDate));
			rset = pstmt.executeQuery();
			
			FlightInfoBean flight;
			
			while(rset.next())
			{
				flight = new FlightInfoBean();
				flight.setFlightNo(rset.getString(1));
				flight.setAirline(rset.getString(2));
				flight.setDeptCity(rset.getString(3));
				flight.setArrCity(rset.getString(4));
				flight.setDeptDate(rset.getString(5));
				flight.setArrDate(rset.getString(6));
				flight.setDeptTime(rset.getString(7).substring(11));
				flight.setArrTime(rset.getString(8).substring(11));
				flight.setFirstSeats(rset.getInt(9));
				flight.setFirstSeatFare(rset.getFloat(10));
				flight.setBussSeats(rset.getInt(11));
				flight.setBussSeatFare(rset.getFloat(12));
				
				flightList.add(flight);
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightList;
	}

	@Override
	public List<String> getFlightNoList() throws AirlineException {
		
		conn = DBUtil.getConnection();
		List<String> flightNoList = new ArrayList<String>();
		
		try
		{	
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.FLIGHT_NO_LIST);
			rset = pstmt.executeQuery();
			
			while(rset.next())
			{
				flightNoList.add(rset.getString(1));
			}
				
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again.");
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		return flightNoList;
	}

	@Override
	public boolean updateFlightDetails(FlightInfoBean flight) throws AirlineException {
		
		conn = DBUtil.getConnection();
		boolean recordUpdated = false;
		int record;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.UPDATE_FLIGHT);
			
			pstmt.setString(1, flight.getAirline());
			pstmt.setString(2, flight.getDeptCity());
			pstmt.setString(3, flight.getArrCity());
			pstmt.setDate(4, ConvertToSQLDate.convertDate(flight.getDeptDate()));
			pstmt.setDate(5, ConvertToSQLDate.convertDate(flight.getArrDate()));
			pstmt.setTimestamp(6, Timestamp.valueOf(flight.getDeptTime()));
			pstmt.setTimestamp(7, Timestamp.valueOf(flight.getArrTime()));
			pstmt.setInt(8, flight.getFirstSeats());
			pstmt.setFloat(9, flight.getFirstSeatFare());
			pstmt.setInt(10, flight.getBussSeats());
			pstmt.setFloat(11, flight.getBussSeatFare());
			pstmt.setString(12, flight.getFlightNo());
			
			record = pstmt.executeUpdate();
			
			if(record == 1)
				recordUpdated = true;
			
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return recordUpdated;
	}

	@Override
	public boolean updateFlightSeats(String bookingId) throws AirlineException {
		
		conn = DBUtil.getConnection();
		boolean updatedRecord = false;
		int record = 0, numPassengers = 0, totalPassengers = 0;
		String classType = null, flightNo = null;
				
		try
		{		
			conn.setAutoCommit(false);
			if(conn == null)
			{
				throw new AirlineException("Connection not established.");
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.BOOKING_UPDATE_REQ);
			pstmt.setString(1, bookingId);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				numPassengers = rset.getInt(1);
				classType = rset.getString(2);
				flightNo = rset.getString(3);				
			}
			
			pstmt = conn.prepareStatement(IQueryMapper.SEAT_NUMBERS);
			pstmt.setString(1, flightNo);
			rset = pstmt.executeQuery();
			
			if(rset.next())
			{
				if(classType.equals("First Class"))
				{
					totalPassengers = rset.getInt(1);
					pstmt = conn.prepareStatement(IQueryMapper.FIRST_CLASS_SEATS_REMAINING);
				}
				else
				{
					totalPassengers = rset.getInt(2);
					pstmt = conn.prepareStatement(IQueryMapper.BUSINESS_CLASS_SEATS_REMAINING);
				}
			}
			
			totalPassengers += numPassengers;
			pstmt.setInt(1, totalPassengers);
			pstmt.setString(2, flightNo);
			record = pstmt.executeUpdate();
			
			if(record == 1)
				updatedRecord = true;
						
			conn.commit();
		}
		catch(SQLException e)
		{
			throw new AirlineException("Technical Issue. Please try again." +e.getMessage());
		}
		
		finally
		{
			try
			{
				if(rset != null)
					rset.close();
				if(pstmt != null)
					pstmt.close();
			}
			catch(SQLException e)
			{
				throw new AirlineException("Connection Issue");
			}
		}
		
		return updatedRecord;
	}

}
