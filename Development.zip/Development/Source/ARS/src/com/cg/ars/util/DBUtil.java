package com.cg.ars.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.ars.exception.AirlineException;

public class DBUtil {

private static Connection conn;
	
	public static Connection getConnection() throws AirlineException
	
	{
		new DBUtil();
		
		//if not connected
		if(conn == null)
		{
			try
			{
				InitialContext context = new InitialContext();
				DataSource source = (DataSource) context.lookup("java:/jdbc/TestDS");
				conn = source.getConnection();
			}
			catch(NamingException exp)
			{
				throw new AirlineException("Error while creating data source " +exp.getMessage());
			}
			catch (SQLException exp)
			{
				throw new AirlineException("Error while obtaining connection " +exp.getMessage());
			}
		}
		return conn;
	}
}
