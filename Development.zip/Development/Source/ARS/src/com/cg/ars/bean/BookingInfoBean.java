package com.cg.ars.bean;

public class BookingInfoBean {

	private String bookingId, custMail, custName, classType, creditCardInfo, srcCity,numPassenger, destCity, totalFare,flightNo;
	
	
	
	public String getBookingId() {
		return bookingId;
	}
	
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	public String getCustMail() {
		return custMail;
	}
	
	public void setCustMail(String custMail) {
		this.custMail = custMail;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	public String getClassType() {
		return classType;
	}
	
	public void setClassType(String classType) {
		this.classType = classType;
	}
	
	public String getCreditCardInfo() {
		return creditCardInfo;
	}
	
	public void setCreditCardInfo(String creditCardInfo) {
		this.creditCardInfo = creditCardInfo;
	}
	
	public String getSrcCity() {
		return srcCity;
	}
	
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}
	
	public String getDestCity() {
		return destCity;
	}
	
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	
	public String getFlightNo() {
		return flightNo;
	}
	
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	
	public String getNumPassenger() {
		return numPassenger;
	}
	
	public void setNumPassenger(String occupancy) {
	
		this.numPassenger = (occupancy);
	}
	
	public String getTotalFare() {
		return totalFare;
	}
	
	public void setTotalFare(String totalFare) {
		this.totalFare = totalFare;
	}
	
}
