package com.cg.ars.service;

import java.util.List;

import com.cg.ars.bean.BookingInfoBean;
import com.cg.ars.bean.CustomerBean;
import com.cg.ars.bean.FlightInfoBean;
import com.cg.ars.bean.UserBean;
import com.cg.ars.dao.AirlineDAOImpl;
import com.cg.ars.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService {

	private AirlineDAOImpl daoObj;
	
	public AirlineServiceImpl() {
		
		daoObj = new AirlineDAOImpl();	
	}
	
	@Override
	public boolean isValidAuthority(UserBean user) throws AirlineException {
		return daoObj.isValidAuthority(user);
	}
	
	@Override
	public boolean isValidUser(UserBean user) throws AirlineException {
		return daoObj.isValidUser(user);
	}

	@Override
	public boolean isAvailableUsername(CustomerBean customer) throws AirlineException {
		return daoObj.isAvailableUsername(customer);
	}

	@Override
	public boolean addNewPassenger(CustomerBean customer, UserBean user) throws AirlineException {
		return daoObj.addNewPassenger(customer, user);
	}

	@Override
	public List<String> findDepartureCities() throws AirlineException {
		return daoObj.findDepartureCities();
	}

	@Override
	public List<String> findArrivalCities() throws AirlineException {
		return daoObj.findArrivalCities();
	}

	@Override
	public List<FlightInfoBean> searchFlightDetails(String deptCity, String arrCity, String deptDate) throws AirlineException {
		return daoObj.searchFlightDetails(deptCity, arrCity, deptDate);
	}

	@Override
	public boolean isSeatAvailable(String flightNo, String seatType, String seatNum) throws AirlineException {
		return daoObj.isSeatAvailable(flightNo, seatType, seatNum);
	}

	@Override
	public String getCustomerMail(String username) throws AirlineException {
		return daoObj.getCustomerMail(username);
	}
	
	@Override
	public String getCustomerName(String username) throws AirlineException {
		return daoObj.getCustomerName(username);
	}

	@Override
	public String getTotalFare(String flightNo, String seatType, String seatNum) throws AirlineException {
		return daoObj.getTotalFare(flightNo, seatType, seatNum);
	}
	

	@Override
	public int bookFlight(BookingInfoBean book) throws AirlineException {
		return daoObj.bookFlight(book);
	}

	@Override
	public boolean updateSeatNum(BookingInfoBean book) throws AirlineException {
		return daoObj.updateSeatNum(book);
	}
	
	@Override
	public List<BookingInfoBean> getCustomerBookingInfo(String username) throws AirlineException {
		return daoObj.getCustomerBookingInfo(username);
	}	

	@Override
	public boolean isValidBookingId(String bookingId, String username) throws AirlineException {
		return daoObj.isValidBookingId(bookingId, username);
	}

	@Override
	public boolean deleteCustomerBooking(String bookingId) throws AirlineException {
		return daoObj.deleteCustomerBooking(bookingId);
	}

	@Override
	public List<String> flightNoListDate(String deptDate, String arrDate) throws AirlineException{
		return daoObj.flightNoListDate(deptDate, arrDate);
	}
	
	@Override
	public List<BookingInfoBean> viewFlightOccupancy(List<String> flightNoList) throws AirlineException {
		return daoObj.viewFlightOccupancy(flightNoList);
	}

	@Override
	public List<String> flightNoListCity(String srcCity, String destCity) throws AirlineException {
		return daoObj.flightNoListCity(srcCity, destCity);
	}

	@Override
	public boolean isAvailableFlightNo(String flightNo) throws AirlineException {
		return daoObj.isAvailableFlightNo(flightNo);
	}
	
	@Override
	public boolean insertFlightDetails(FlightInfoBean flight) throws AirlineException {
		return daoObj.insertFlightDetails(flight);
	}

	@Override
	public boolean deleteFlightDetails(String flightNo) throws AirlineException {
		return daoObj.deleteFlightDetails(flightNo);
	}

	@Override
	public List<FlightInfoBean> viewAllFlightSchedules() throws AirlineException {
		return daoObj.viewAllFlightSchedules();
	}

	@Override
	public FlightInfoBean viewFlightSchedule(String flightNo) throws AirlineException {
		return daoObj.viewFlightSchedule(flightNo);
	}

	@Override
	public List<CustomerBean> getPassengerList(String flightNo) throws AirlineException {
		return daoObj.getPassengerList(flightNo);
	}

	@Override
	public List<BookingInfoBean> getBookingList(String flightNo) throws AirlineException {
		return daoObj.getBookingList(flightNo);
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleDestCity(String destCity) throws AirlineException {
		return daoObj.viewFlightScheduleDestCity(destCity);
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleSrcCity(String srcCity) throws AirlineException {
		return daoObj.viewFlightScheduleSrcCity(srcCity);
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleDeptDate(String deptDate) throws AirlineException {
		return daoObj.viewFlightScheduleDeptDate(deptDate);
	}

	@Override
	public List<FlightInfoBean> viewFlightScheduleArrDate(String arrDate) throws AirlineException {
		return daoObj.viewFlightScheduleArrDate(arrDate);
	}

	@Override
	public List<String> getFlightNoList() throws AirlineException {
		return daoObj.getFlightNoList();
	}

	@Override
	public boolean updateFlightDetails(FlightInfoBean flight) throws AirlineException {
		return daoObj.updateFlightDetails(flight);
	}

	@Override
	public boolean updateFlightSeats(String bookingId) throws AirlineException {
		return daoObj.updateFlightSeats(bookingId);
	}
	
}
