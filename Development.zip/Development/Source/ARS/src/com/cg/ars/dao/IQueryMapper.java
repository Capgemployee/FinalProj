package com.cg.ars.dao;

public interface IQueryMapper {

	public static final String USER_PASSWORD_ROLE = "SELECT password, role FROM USERS WHERE username = ?";
	public static final String USER_PASSWORD = "SELECT password FROM USERS WHERE username = ?";
	public static final String USERNAME_LIST = "SELECT username FROM USERS";
	public static final String REGISTER_CUSTOMER = "INSERT INTO Customer VALUES(?, ?, ?, ?, ?)";
	public static final String ADD_NEW_USER = "INSERT INTO USERS VALUES(?, ?, 'passenger', ?)";
	public static final String DEPARTURE_CITY_LIST = "SELECT DISTINCT(dep_city) FROM FlightInformation ORDER BY dep_city";
	public static final String ARRIVAL_CITY_LIST = "SELECT DISTINCT(arr_city) FROM FlightInformation ORDER BY arr_city";
	public static final String SEARCH_FLIGHT_DETAILS = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE dep_city = ? AND arr_city = ? AND dep_date >= ?";
	public static final String SEAT_NUMBERS = "SELECT FirstSeats, BussSeats FROM FlightInformation WHERE flightno=?";
	public static final String CUSTOMER_MAIL = "SELECT email FROM Customer WHERE username = ?";
	public static final String CUSTOMER_NAME = "SELECT firstName, lastName FROM Customer WHERE username = ?";
	public static final String FIRST_CLASS_FARE = "SELECT FirstSeatFare FROM FlightInformation WHERE flightno = ?";
	public static final String BUSINESS_CLASS_FARE = "SELECT BussSeatsFare FROM FlightInformation WHERE flightno = ?";
	public static final String BOOK_FLIGHT = "INSERT INTO BookingInformation VALUES(booking_id_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?,?)";
	public static final String BOOKING_ID = "SELECT booking_id_seq.CURRVAL FROM DUAL";
	public static final String FIRST_CLASS_SEATS_REMAINING = "UPDATE FlightInformation SET FirstSeats = ? WHERE flightno = ?";
	public static final String BUSINESS_CLASS_SEATS_REMAINING = "UPDATE FlightInformation SET BussSeats = ? WHERE flightno = ?";
	public static final String CUSTOMER_BOOKING_INFO = "SELECT Booking_id, no_of_passengers, class_type, total_fare, src_city, dest_city, flightno FROM BookingInformation WHERE cust_name = ?";
	public static final String BOOKING_CUSTOMER_NAME = "SELECT cust_name FROM BookingInformation WHERE Booking_id = ?";
	public static final String CUTOMER_DELETE_BOOKING = "DELETE FROM BookingInformation WHERE Booking_id = ?";
	public static final String FLIGHT_NO_LIST_DATE = "SELECT flightno FROM FlightInformation where dep_date = ? and arr_date = ?";
	public static final String OCCUPANCY_COUNT = "SELECT no_of_passengers FROM BookingInformation WHERE flightno = ?";
	public static final String FLIGHT_NO_LIST_CITY = "SELECT flightno FROM FlightInformation WHERE dep_city = ? and arr_city = ?";
	public static final String ADD_NEW_FLIGHT = "INSERT INTO FlightInformation VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public static final String FIND_FLIGHT = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE flightno = ?";
	public static final String FLIGHT_NO_LIST = "SELECT flightno FROM FlightInformation";
	public static final String DELETE_FLIGHT = "DELETE FROM FlightInformation WHERE flightno = ?";
	public static final String ALL_FLIGHTS = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation ORDER BY flightno";
	public static final String VIEW_FLIGHTID_SCHEDULE = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE flightno = ?";
	public static final String PASSENGER_LIST = "SELECT DISTINCT firstName, lastName, email, mobile_no FROM CUSTOMER WHERE email IN (SELECT cust_email FROM BookingInformation WHERE flightno = ?)";
	public static final String BOOKING_LIST = "SELECT Booking_id, cust_name, no_of_passengers, class_type FROM BookingInformation WHERE flightno = ? ORDER BY Booking_id";
	public static final String FLIGHT_DETAILS_DEST_CITY = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE arr_city = ?";
	public static final String FLIGHT_DETAILS_SRC_CITY = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE dep_city = ?";
	public static final String FLIGHT_DETAILS_DEPT_DATE = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE dep_date = ?";
	public static final String FLIGHT_DETAILS_ARR_DATE = "SELECT flightno, airline, dep_city, arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM FlightInformation WHERE arr_date = ?";
	public static final String UPDATE_FLIGHT = "UPDATE FlightInformation SET airline = ?, dep_city = ?, arr_city = ?, dep_date = ?, arr_date = ?, dep_time = ?, arr_time = ?, FirstSeats = ?, FirstSeatFare = ?, BussSeats = ?, BussSeatsFare = ? WHERE flightno = ?";
	public static final String BOOKING_UPDATE_REQ = "SELECT no_of_passengers, class_type, flightno FROM BookingInformation WHERE Booking_id = ?";
}
