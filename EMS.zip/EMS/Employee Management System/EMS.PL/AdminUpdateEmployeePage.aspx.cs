﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;

public partial class AdminUpdateEmployeePage : System.Web.UI.Page
{
    public bool EmployeeInfoVisible
    {
        get { return empDiv.Visible; }
        set
        { empDiv.Visible = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
       
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

       

    }
    protected void btnAddEmployee_Click(object sender, EventArgs e)
    {
        try
        {
            Employee emp = new Employee();
            AdminValidations adminValid = new AdminValidations();
            emp.EmpID = Convert.ToInt32(txtEmpID.Text);
            // emp.UserID = Session["User"].ToString();
            emp.UserID = txtUserID.Text;
            emp.EmpFName = txtFirstName.Text;
            emp.EmpLName = txtLastName.Text;
            emp.EmpEmailId = txtEmail.Text;
            emp.EmpContactNo = txtContactNo.Text;
            emp.EmpDOB = Convert.ToDateTime(txtDOB.Text);
            emp.EmpAge = Convert.ToInt32(txtAge.Text);
            emp.EmpAddress = txtAddress.Text;
            emp.EmpSkills = txtDesignation.Text;
            emp.EmpSalary = Convert.ToDouble(txtDesignation1.Text);
            emp.EmpDesignation = txtDesignation0.Text;
            emp.EmpDOJ = Convert.ToDateTime(txtDOB0.Text);

            if (genderMale.Checked)
            {
                emp.EmpGender = Convert.ToChar('M');
            }
            if (genderFemale.Checked)
            {
                emp.EmpGender = Convert.ToChar('F');
            }

            bool empUpdated = adminValid.AdminUpdateRecordBL(emp);
            if (empUpdated)
            {
                Response.Write("<script>alert('Employee Updated')</script>");
            }

            else
            {
                Response.Write("<script>alert('Employee Record Not Updated')</script>");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            EmployeeInfoVisible = true;
            int empId = Convert.ToInt32(txtEmpID.Text);
            Employee emp = new Employee();
            AdminValidations adminValid = new AdminValidations();
            DataTable table = adminValid.SearchRecordByIDBL(empId);
            if (table != null)
            {

                txtUserID.Text = table.Rows[0]["UserID"].ToString();
                txtFirstName.Text = table.Rows[0]["EmpFName"].ToString();
                txtLastName.Text = table.Rows[0]["EmpLName"].ToString();
                txtDOB.Text = table.Rows[0]["EmpDOB"].ToString();
                txtDOB0.Text = table.Rows[0]["EmpDOJ"].ToString();
                txtDesignation1.Text = table.Rows[0]["EmpSalary"].ToString();
                txtAge.Text = table.Rows[0]["EmpAge"].ToString();
                txtDesignation0.Text = table.Rows[0]["EmpDesignation"].ToString();
                txtEmail.Text = table.Rows[0]["EmpEmailId"].ToString();
                txtContactNo.Text = table.Rows[0]["EmpContactNo"].ToString();
                txtAddress.Text = table.Rows[0]["EmpAddress"].ToString();
                txtDesignation.Text = table.Rows[0]["EmpSkills"].ToString();
                string gender = table.Rows[0]["EmpGender"].ToString();
                if (gender == "M")
                {
                    genderMale.Checked = true;
                }
                else
                {
                    genderFemale.Checked = true;
                }
            }
            else
            {
                Response.Write("Record Not Found");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        txtAddress.Text = "";
        txtAge.Text = "";
        txtContactNo.Text = "";
        txtDesignation.Text = "";
        txtDesignation1.Text = "";
        txtDOB.Text = "";
        txtEmail.Text = "";
        txtEmpID.Text = "";
        txtFirstName.Text = "";
        txtLastName.Text = "";
        txtUserID.Text = "";
        txtAge.Text = "";
    }
}