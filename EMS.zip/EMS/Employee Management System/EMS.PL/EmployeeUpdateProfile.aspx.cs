﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;

public partial class EmployeeUpdateProfile : System.Web.UI.Page
{
    public bool EmployeeInfoVisible
    {
        get { return empUpdateDiv.Visible; }
        set
        { empUpdateDiv.Visible = value; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

      
    }
    protected void btnAddEmployee_Click(object sender, EventArgs e)
    {
        try
        {
            Employee emp = new Employee();
            EmployeeValidations empValid = new EmployeeValidations();
            emp.EmpID = Convert.ToInt32(txtEmpID.Text);
            emp.EmpFName = txtFirstName.Text;
            emp.EmpLName = txtLastName.Text;
            emp.EmpEmailId = txtEmail.Text;
            emp.EmpContactNo = txtContactNo.Text;
            emp.EmpDOB = Convert.ToDateTime(txtDOB.Text);
            emp.EmpAge = Convert.ToInt32(txtAge.Text);
            emp.EmpAddress = txtAddress.Text;
            emp.EmpSkills = txtSkill.Text;

            bool empUpdated = empValid.EmpUpdateRecordBL(emp);
            if (empUpdated)
            {
                Response.Write("<script>alert('Employee Updated')</script>");
            }

            else
            {
                Response.Write("<script>alert('Employee Record Not Updated')</script>");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

    }

    protected void btnViewEmployee_Click(object sender, EventArgs e)
    {
        try
        {
            EmployeeInfoVisible = true;
            EmployeeValidations empValid = new EmployeeValidations();
            DataTable table = empValid.MyInfo(Session["user"].ToString());

            if (table != null)
            {
                txtEmpID.Text = table.Rows[0]["EmpID"].ToString();
                txtFirstName.Text = table.Rows[0]["EmpFName"].ToString();
                txtLastName.Text = table.Rows[0]["EmpLName"].ToString();
                txtDOB.Text = table.Rows[0]["EmpDOB"].ToString();
                txtAge.Text = table.Rows[0]["EmpAge"].ToString();
                txtEmail.Text = table.Rows[0]["EmpEmailId"].ToString();
                txtContactNo.Text = table.Rows[0]["EmpContactNo"].ToString();
                txtAddress.Text = table.Rows[0]["EmpAddress"].ToString();
                txtSkill.Text = table.Rows[0]["EmpSkills"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Record Not Found')</script>");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }
  
}