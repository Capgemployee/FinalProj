﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
public partial class AdminSearchPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (Regex.IsMatch(txtEmpID.Text, @"[a-zA-Z]"))
        {
            try
            {
                Employee emp = new Employee();
                string temp = txtEmpID.Text;
                AdminValidations obj = new AdminValidations();
                DataTable table = obj.SearchRecordBL(temp);
                grdSearchEmp.DataSource = table;
                grdSearchEmp.DataBind();
            }
            catch (CustomException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
            catch (SqlException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
        }
        else if (Regex.IsMatch(txtEmpID.Text, @"^[0-9]+$")) 
        {
            try
            {
                int empId = Convert.ToInt32(txtEmpID.Text);
                Employee emp = new Employee();
                AdminValidations adminValid = new AdminValidations();
                DataTable table = adminValid.SearchRecordByIDBL(empId);
                grdSearchEmp.DataSource = table;
                grdSearchEmp.DataBind();
            }
            catch (CustomException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
            catch (SqlException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }

        }

    }
}