﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;


public partial class AdminAddPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

    }

    protected void btnAddEmployee_Click(object sender, EventArgs e)
    {
        try
        {
            Employee emp = new Employee();
            AdminValidations adminValid = new AdminValidations();
            emp.UserID = Session["User"].ToString();
            emp.UserID = txtUserID.Text;
            emp.EmpFName = txtFirstName.Text;
            emp.EmpLName = txtLastName.Text;
            emp.EmpEmailId = txtEmail.Text;
            emp.EmpContactNo = txtContactNo.Text;
            emp.EmpDOB = Convert.ToDateTime(txtDOB.Text);
            emp.EmpAge = Convert.ToInt32(txtAge.Text);
            emp.EmpAddress = txtAddress.Text;
            emp.EmpSkills = txtskills.Text;
            emp.EmpSalary = Convert.ToDouble(txtSalary.Text);
            emp.EmpDesignation = txtDesignation.Text;
            emp.EmpDOJ = Convert.ToDateTime(txtDOJ.Text);
            if (genderMale.Checked)
            {
                emp.EmpGender = Convert.ToChar('M');
            }
            if (genderFemale.Checked)
            {
                emp.EmpGender = Convert.ToChar('F');
            }

            bool empAdded = adminValid.AddRecordBL(emp);
            if (empAdded)
            {
                Response.Write("<script>alert('Employee Added')</script>");
            }

            else
            {
                Response.Write("<script>alert('Employee Record Not Added')</script>");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }
}