﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;

namespace EMS.PL
{
    public partial class Login : System.Web.UI.Page
    {
        Logins log = new Logins();
        LoginValidations logValidate = new LoginValidations();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberTable = new DataTable();
            try
            {
                memberTable = validationObj.ValidateUserBL(txtUserName.Text, txtPassword.Text);
                if (memberTable.Rows[0].ItemArray[2].ToString() == "Admin")
                {
                    Session["User"] = txtUserName.Text;
                    Response.Redirect("DefaultAdminPage.aspx");
                }
                else if (memberTable.Rows[0].ItemArray[2].ToString() != "Admin")
                {
                    Session["User"] = txtUserName.Text;
                    Response.Redirect("DefaultEmployeePage.aspx");
                }
                else
                {
                    Response.Write("<script> alert('Invalid Username/Password'); </script>");
                }
            }
            catch (CustomException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
            catch (SqlException )
            {
                Response.Write("<script> alert('Invalid Username/Password'); </script>");
            }
            catch (SystemException )
            {
                Response.Write("<script> alert('Invalid Username/Password'); </script>");
            }

           
        }

        protected void ddUserType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtUserName_TextChanged(object sender, EventArgs e)
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            try
            {
                memberAdded = validationObj.PasswordCheckBL(txtUserName.Text);
                if (memberAdded.Rows[0]["UserPswd"].ToString() == null || memberAdded.Rows[0]["UserPswd"].ToString() == string.Empty)
                {
                    lblRePassword.Visible = true;
                    txtRePassword.Visible = true;
                }
                else
                {
                   
                }
            }
            catch (CustomException ex)
            {
                Response.Write("<script> alert('" + ex.Message + "'); </script>");
            }
            catch (SqlException)
            {
                Response.Write("<script> alert('User ID is not Valid'); </script>");
            }
            catch (SystemException)
            {
                Response.Write("<script> alert('User ID is not Valid'); </script>");
            }
        }

        protected void txtRePassword_TextChanged(object sender, EventArgs e)
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
                try
                {
                    if(txtPassword.Text==txtRePassword.Text)
                    {
                    bool memberAd = validationObj.PasswordSetBL(txtUserName.Text, txtRePassword.Text);
                    if (memberAd)
                    {
                        Response.Write("<script> alert('Password Set, Pase Login'); </script>");
                        txtPassword.Text = "";
                        lblRePassword.Visible = false;
                        txtRePassword.Visible = false;
                    }
                    else
                    {
                        Response.Write("<script> alert('Password Not Set, Please Try Again'); </script>");
                    }
                    }
                    else
                    {
                        Response.Write("<script> alert('Both Password must be match'); </script>");
                    }
                }
                catch (CustomException ex)
                {
                    Response.Write("<script> alert('" + ex.Message + "'); </script>");
                }
                catch (SqlException ex)
                {
                    Response.Write("<script> alert('" + ex.Message + "'); </script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script> alert('" + ex.Message + "'); </script>");
                }
        }
    }
}