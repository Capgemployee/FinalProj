﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;
public partial class AdminDeletePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }


    }
    protected void btnDeleteEmployee_Click(object sender, EventArgs e)
    {
        try
        {
            Project proj = new Project();
            proj.EmpID = Convert.ToInt32(txtDelEmp.Text);
            AdminValidations adminValidation = new AdminValidations();
            bool EmpDelete = adminValidation.DeleteRecordBL(proj.EmpID);
            if (EmpDelete)
            {
                Response.Write("<script> alert('Employee Record Deleted'); </script>");
            }

            else
            {
                Response.Write("<script>alert('Employee Record Not Found');</script>");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }

    protected void txtDelEmp_TextChanged(object sender, EventArgs e)
    {

    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            Employee emp = new Employee();
            int temp = Convert.ToInt32(txtDelEmp.Text);
            AdminValidations obj = new AdminValidations();
            DataTable table = obj.SearchRecordByIDBL(temp);
            grdDelete.DataSource = table;
            grdDelete.DataBind();
            
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('Record Not Found'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('Record Not Found'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }
}