﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Class Name           :- Entity to store Custom Exception
    /// Author               :- Karndeep Rana
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    public class CustomException:ApplicationException
    {
        public CustomException() : base() { }
        public CustomException(string message) : base(message) { }
    }
}
