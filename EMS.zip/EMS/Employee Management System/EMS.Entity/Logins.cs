﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Class Name           :- Entity to store Login Information
    /// Author               :- Shruti Jamgade
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class Logins
    {
        /// <summary>
        /// Property to store and retrieve UserID
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// Property to store and retrieve UserPswd
        /// </summary>
        public string UserPswd { get; set; }

        /// <summary>
        /// Property to store and retrieve UserType
        /// </summary>
        public string UserType { get; set; }
    }
}
