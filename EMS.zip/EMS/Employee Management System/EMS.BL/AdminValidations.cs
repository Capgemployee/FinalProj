﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.DAL;
using EMS.Entity;
using EMS.Exception;

namespace EMS.BL
{
    /// <summary>
    /// Class Name           :- Class to validate Admin information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
   public class AdminValidations
    {
        AdminOperations operationObj = new AdminOperations();

        public bool ValidateEmp(Employee employeeObj)
        {
            bool validdata = true;
            StringBuilder sb = new StringBuilder();

            if (validdata == false)
                throw new CustomException(sb.ToString());
            return validdata;
        }

        public bool ValidateProj(Project projectObj)
        {
            bool validdata = true;
            StringBuilder sb = new StringBuilder();


            if (validdata == false)
                throw new CustomException(sb.ToString());
            return validdata;
        }

        public bool AddRecordBL(Employee employeeObj)
        {
            try
            {
                bool employeeAdded = false;
                if (ValidateEmp(employeeObj))
                    employeeAdded = operationObj.AddRecord(employeeObj);
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool AdminUpdateRecordBL(Employee employeeObj)
        {
            try
            {
                bool employeeAdded = false;
                if (ValidateEmp(employeeObj))
                    employeeAdded = operationObj.AdminUpdateRecord(employeeObj);
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool DeleteRecordBL(int EmpID)
        {
            try
            {
                bool employeeDel = operationObj.DeleteRecord(EmpID);
                return employeeDel;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable SearchRecordBL(string param)
        {
            try
            {
                DataTable employeeSearch = operationObj.SearchRecord(param);
                return employeeSearch;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool AddProjectBL(Project projectObj)
        {
            try
            {
                bool employeeAdded = false;
                if (ValidateProj(projectObj))
                    employeeAdded = operationObj.AddProject(projectObj);
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable MyInfoBL(string UserID)
        {
            try
            {
                DataTable employeeSearch = operationObj.MyInfo(UserID);
                return employeeSearch;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable BirthdayBL()
        {
            try
            {
                DataTable employeeAdded = operationObj.Birthday();
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable SearchRecordByIDBL(int EmpID)
        {
            try
            {
                DataTable employeeSearch = operationObj.SearchRecordByID(EmpID);
                return employeeSearch;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

    }
}
