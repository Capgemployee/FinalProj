﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.DAL;
using EMS.Entity;
using EMS.Exception;

namespace EMS.BL
{
    /// <summary>
    /// Class Name           :- Class to validate Employee information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class EmployeeValidations
    {
        EmployeeOperations operationObj = new EmployeeOperations();

        public bool ValidateEmp(Employee employeeObj)
        {
            try
            {
                bool validdata = true;
                StringBuilder sb = new StringBuilder();

                if (validdata == false)
                    throw new CustomException(sb.ToString());
                return validdata;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool EmpUpdateRecordBL(Employee employeeObj)
        {
            try
            {
                bool employeeAdded = false;
                if (ValidateEmp(employeeObj))
                    employeeAdded = operationObj.EmpUpdateRecord(employeeObj);
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable MyInfo(string UserID)
        {
            try
            {
                DataTable employeeSearch = operationObj.MyInfo(UserID);
                return employeeSearch;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable BirthdayBL()
        {
            try
            {
                DataTable employeeAdded = operationObj.Birthday();
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

    }
}
