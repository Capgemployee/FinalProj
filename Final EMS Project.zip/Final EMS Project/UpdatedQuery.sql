USE [Training_18Jan2017_Talwade]
GO

--###################################################
CREATE SCHEMA [MySchemaEMS]
GO

--###################### TABLES #####################
CREATE TABLE [MySchemaEMS].EmployeeDetails
(
EmpID INT IDENTITY(121100,1) PRIMARY KEY,
EmpFName VARCHAR(20) NOT NULL,
EmpLName VARCHAR(20) NOT NULL,
EmpGender CHAR NOT NULL
CONSTRAINT CHK_Gender CHECK (EmpGender='M' OR EmpGender='F'),
EmpAge INT NOT NULL
CONSTRAINT CHK_Age CHECK(EmpAge>=18 AND EmpAge<=60),
EmpDesignation VARCHAR(20) NOT NULL,
EmpSkills VARCHAR(30) NOT NULL,
EmpSalary NUMERIC(10,2) NOT NULL,
EmpAddress VARCHAR(50) NOT NULL,
EmpDOB Date NOT NULL,
EmpDOJ Datetime NOT NULL,
EmpContactNo CHAR(10) NOT NULL,
EmpEmailId VARCHAR(30) NOT NULL,
UserID VARCHAR(30) FOREIGN KEY REFERENCES [MySchemaEMS].LoginDetails(UserID)
)

CREATE TABLE [MySchemaEMS].LoginDetails(
UserID VARCHAR(30) PRIMARY KEY,
UserPswd VARCHAR(30),
UserType VARCHAR(20)
)


CREATE TABLE [MySchemaEMS].ProjectDetails(
EmpID INT FOREIGN KEY REFERENCES [MySchemaEMS].EmployeeDetails(EmpID),
ProjectID INT,
ProjectName VARCHAR(40) NOT NULL,
ProjectTechnology VARCHAR(50) NOT NULL,
ProjectStatus VARCHAR(15) NOT NULL
)


--################# SELECT COMMAND ###########################

SELECT * FROM  [MySchemaEMS].EmployeeDetails 

SELECT * FROM  [MySchemaEMS].LoginDetails

SELECT * FROM  [MySchemaEMS].ProjectDetails

--################# DROP COMMAND ##############################

DROP TABLE [MySchemaEMS].EmployeeDetails

DROP TABLE [MySchemaEMS].LoginDetails

DROP TABLE [MySchemaEMS].ProjectDetails

--################# INSERT COMMAND ##############################

INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Shruti','Hassan','F',22,'Developer','DOT.NET',200000,'Nagpur','03/24/2017','01/18/2017',9870657483,'shruti@gmail.com','s_jamgade')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Karan','Chavan','M',22,'Developer','JAVA',2000,'Mumbai','04/20/2017','01/18/2017',9870657883,'karan@gmail.com','k_chavan')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Vinit','Surya','M',22,'Developer','TESTING',50000,'Pune','04/24/2017','01/18/2017',9870657083,'vinit@gmail.com','v_surya')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Karndeep','Rana','M',22,'Developer','Testing',50000,'Mahim','04/24/2017','01/18/2017',9898989887,'rana@gmail.com','k_rana')


INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Saurabh','Dubey','M',22,'Admin','Management',50000,'Pune','04/24/2017','01/18/2017',9870657083,'saurabh@gmail.com','s_dubey')


INSERT INTO [MySchemaEMS].LoginDetails
VALUES('s_dubey','root','Admin')

INSERT INTO [MySchemaEMS].LoginDetails
VALUES('s_jamgade','shruti123','Employee')
INSERT INTO [MySchemaEMS].LoginDetails
VALUES('k_chavan','karan123','Employee')
INSERT INTO [MySchemaEMS].LoginDetails
VALUES('v_surya','vinit123','Employee')

INSERT INTO [MySchemaEMS].ProjectDetails
VALUES(NUll,1001,'EMS','JAVA','Pending')
INSERT INTO [MySchemaEMS].ProjectDetails
VALUES(NULL,1002,'HMS','DOTNET','Completed')

--############# STORED PROCEDURE OF EMPLOYEE #############################

ALTER PROCEDURE [MySchemaEMS].usp_UpdateEmployeeInfo
(
	@UserID INT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpAge INT,
	@EmpSkills VARCHAR(30),
	@EmpAddress VARCHAR(50),
	@EmpDOB Date,
	@EmpContactNo CHAR(10),
	@EmpEmailId VARCHAR(30)	
)
AS
UPDATE [MySchemaEMS].EmployeeDetails 
SET EmpFName=@EmpFName,EmpLName=@EmpLName,EmpAge=@EmpAge,
@EmpSkills=EmpSkills,EmpAddress=@EmpAddress,EmpDOB=@EmpDOB,
EmpContactNo=@EmpContactNo,EmpEmailId=@EmpEmailId
WHERE UserID=@UserID


----############# STORED PROCEDURE OF ADMIN #############################

ALTER PROCEDURE [MySchemaEMS].usp_AddEmployeeRecord
(
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpGender CHAR,
	@EmpAge INT,
	@EmpDesignation VARCHAR(20),
	@EmpSkills VARCHAR(30),
	@EmpSalary NUMERIC(10,2),
	@EmpAddress VARCHAR(50),
	@EmpDOB Datetime,
	@EmpDOJ Datetime,
	@EmpContactNo NUMERIC(10),
	@EmpEmailId VARCHAR(30),
	@UserID VARCHAR(30)	
)
AS
BEGIN

EXEC [MySchemaEMS].usp_AddUserID @UserID, @EmpDesignation

INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES(@EmpFName,@EmpLName,@EmpGender,@EmpAge,@EmpDesignation,@EmpSkills,@EmpSalary,
@EmpAddress,@EmpDOB,@EmpDOJ,@EmpContactNo,@EmpEmailId,@UserID)

END


delete from [MySchemaEMS].EmployeeDetails
where EmpID=121101

delete from [MySchemaEMS].LoginDetails
where UserID='s_patil'


CREATE PROCEDURE [MySchemaEMS].usp_SearchEmployee
(
@EmpSearch VARCHAR(30)
)
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails
WHERE EmpSkills=@EmpSearch or EmpFName=@EmpSearch or EmpDesignation=@EmpSearch

EXEC [MySchemaEMS].usp_SearchEmployee Saurabh

ALTER PROCEDURE [MySchemaEMS].usp_DisplayAllEmployeeDetails
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails


ALTER PROCEDURE [MySchemaEMS].usp_DeleteEmployeeRecord
(
	@EmpID INT
)
AS
DELETE FROM [MySchemaEMS].EmployeeDetails
WHERE  EmpID=@EmpID


ALTER PROCEDURE [MySchemaEMS].usp_UpdateEmployeeRecord
(
	@EmpID INT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpGender CHAR,
	@EmpAge INT,
	@EmpDesignation VARCHAR(20),
	@EmpSkills VARCHAR(30),
	@EmpSalary NUMERIC(10,2),
	@EmpAddress VARCHAR(50),
	@EmpDOB Datetime,
	@EmpDOJ Datetime,
	@EmpContactNo NUMERIC(10),
	@EmpEmailId VARCHAR(30),
	@UserID VARCHAR(30)		
)
AS
UPDATE [MySchemaEMS].EmployeeDetails 
SET EmpFName=@EmpFName,EmpLName=@EmpLName,EmpGender=@EmpGender,EmpAge=@EmpAge,EmpDesignation=@EmpDesignation,
EmpSkills=@EmpSkills,EmpSalary=@EmpSalary,EmpAddress=@EmpAddress,EmpDOB=@EmpDOB,EmpDOJ=@EmpDOJ,
EmpContactNo=@EmpContactNo,EmpEmailId=@EmpEmailId,UserID=@UserID
WHERE EmpID=@EmpID


----############# COMMON STORED PROCEDURE OF EMPLOYEE AND ADMIN #############################

ALTER PROCEDURE [MySchemaEMS].usp_EmployeeInfo
(
	@UserID	VARCHAR(30)
)
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails
WHERE UserID = @UserID


ALTER PROCEDURE [MySchemaEMS].usp_EmployeeBirthday
AS
SELECT  EmpID, EmpFName, EmpLName, EmpAddress, EmpDOB, EmpDOJ, EmpContactNo, EmpEmailId
FROM [MySchemaEMS].EmployeeDetails
WHERE DATEPART( month, EmpDOB)=DATEPART( month, GETDATE());


--############# STORED PROCEDURE OF LOGIN #############################

Alter PROC [MySchemaEMS].usp_ValidateLoginDetails
(
	@UserID	VARCHAR(30),
	@UserPswd VARCHAR(30)
)
AS
BEGIN
	SELECT * FROM LoginDetails 
	WHERE UserID = @UserID AND UserPswd = @UserPswd 
END  



ALTER PROC [MySchemaEMS].usp_PasswordCheck
(
	@UserID	VARCHAR(30)
)
AS
BEGIN
	SELECT * FROM LoginDetails 
	WHERE UserID = @UserID 
END 



ALTER PROC [MySchemaEMS].usp_PasswordSet
(
	@UserID	VARCHAR(30),
	@UserPswd VARCHAR(30)
)
AS
BEGIN
	UPDATE LoginDetails
	SET  UserPswd = @UserPswd
	WHERE UserID = @UserID 
END 


ALTER PROC [MySchemaEMS].usp_AddUserID
(
	@UserID	VARCHAR(30),
	@UserType VARCHAR(20)
)
AS
BEGIN
	INSERT INTO LoginDetails(UserID,UserType)
	VALUES(@UserID,@UserType)
END 

--################### STORED PROCEDURE OF PROJECT DETAILS ###################


ALTER PROC [MySchemaEMS].usp_ViewPendingProject
AS
SELECT ProjectID, ProjectName, ProjectTechnology, ProjectStatus
FROM [MySchemaEMS].ProjectDetails
WHERE ProjectStatus='Pending'


ALTER PROC [MySchemaEMS].usp_ViewProjectDetails
AS
SELECT * FROM [MySchemaEMS].ProjectDetails


ALTER PROC [MySchemaEMS].usp_AllocateEmployee
(
@EmpID INT,
@ProjectID INT
)
AS
UPDATE [MySchemaEMS].ProjectDetails
SET EmpID=@EmpID
WHERE ProjectID=@ProjectID


--################### EXECUTE PROCEDURE ###################

EXEC [MySchemaEMS].usp_AddEmployeeRecord
'Karnadeep','Rana','M',22,'Developer','Testing',45000,'Pune','04/14/2017','01/18/2017',9898989887,
'rana@gmail.com','k_rana'

EXEC [MySchemaEMS].usp_PasswordSet k_rana, rana123 

Exec [MySchemaEMS].usp_ValidateLoginDetails v_surya, vinit123

EXEC [MySchemaEMS].usp_PasswordCheck k_rana

EXEC [MySchemaEMS].usp_ViewPendingProject

EXEC [MySchemaEMS].usp_ViewProjectDetails

EXEC [MySchemaEMS].usp_AllocateEmployee 121102, 1001