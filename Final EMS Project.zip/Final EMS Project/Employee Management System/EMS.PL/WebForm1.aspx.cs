﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.DAL;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;
using System.Data.SqlClient;
using System.Data;

namespace EMS.PL
{
    public partial class WebForm1 : System.Web.UI.Page
    {
       
        EmployeeValidations validationObj = new EmployeeValidations();
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            AdminValidations validationObj = new AdminValidations();
            try
            {
                Employee emp = new Employee();
                emp.EmpFName = "Shital";
                emp.EmpLName = "Patil";
                emp.EmpGender = 'F';
                emp.EmpAge = 19;
                emp.EmpDesignation = "Developer";
                emp.EmpSkills = "Testing";
                emp.EmpSalary = 12000;
                emp.EmpAddress = "Thane";
                emp.EmpDOB = DateTime.Today;
                emp.EmpDOJ = DateTime.Today;
                emp.EmpContactNo = Convert.ToString(9898989898);
                emp.EmpEmailId = "shital@gmail.com";
                emp.UserID="s_patil";



                bool memberAdded = validationObj.AddRecordBL(emp);
                if (memberAdded)
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Added Succesfully";
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Not Added Succesfully";
                }

            }
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
             AdminValidations validationObj = new AdminValidations();
            DataTable memberTable = new DataTable();
            string userID = "k_rana";
           
                try
                {
                    memberTable = validationObj.MyInfoBL(userID);
                    Label1.Visible = true;
                    Label1.Text = "Data  Found";
                }
                catch
                {
                    Label1.Visible = true;
                    Label1.Text = "Data Not Found";
                }
                Label1.Text = memberTable.Rows[0]["UserID"].ToString();
            }

        protected void Button2_Click(object sender, EventArgs e)
        {
            AdminValidations validationObj = new AdminValidations();
            try
            {
                Employee emp = new Employee();
                emp.EmpID = 121107;
                emp.EmpFName = "Shital";
                emp.EmpLName = "Patil";
                emp.EmpGender = 'F';
                emp.EmpAge = 19;
                emp.EmpDesignation = "Developer";
                emp.EmpSkills = "Testing";
                emp.EmpSalary = 12000;
                emp.EmpAddress = "Pune";
                emp.EmpDOB = DateTime.Today;
                emp.EmpDOJ = DateTime.Today;
                emp.EmpContactNo = Convert.ToString(9898989898);
                emp.EmpEmailId = "shital@gmail.com";
                emp.UserID = "s_patil";



                bool memberAdded = validationObj.AdminUpdateRecordBL(emp);
                if (memberAdded)
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Added Succesfully";
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Not Added Succesfully";
                }

            }
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            AdminValidations validationObj = new AdminValidations();
            try
            {
                int EmpID = 121108;

                DataTable memberAdded = validationObj.DeleteRecordBL(EmpID);
                    Label1.Visible = true;
                    Label1.Text = "Record Added Succesfully";

            }
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            AdminValidations validationObj = new AdminValidations();
            DataTable memberAdded = new DataTable();
            try
            {
                string param = "Rana";

                 memberAdded = validationObj.SearchRecordBL(param);
                Label1.Visible = true;
                Label1.Text = "Record Added Succesfully";

            }
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            AdminValidations validationObj = new AdminValidations();
            try
            {
                Project proj = new Project();
                proj.EmpID = 121104;
                proj.ProjectID = 1001;
                bool memberAdded = validationObj.AddProjectBL(proj);
                if (memberAdded)
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Added Succesfully";
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Not Added Succesfully";
                }

            }
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            AdminValidations validationObj = new AdminValidations();
            DataTable memberAdded = new DataTable();
            try
            {
                memberAdded = validationObj.BirthdayBL();
                Label1.Visible = true;
                Label1.Text = "Record Added Succesfully";
                Label1.Text = memberAdded.Rows[0]["EmpFName"].ToString();

            }
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }
           
            
        }
    }
