﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.BL;
using EMS.Exception;

namespace EMS.PL
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            Label1.Text = "even occur";
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            try
            {
                
                memberAdded = validationObj.PasswordCheckBL(TextBox1.Text);
                Label1.Visible = true;
                Label1.Text = "Record Added Succesfully";
                if (memberAdded.Rows[0]["UserPswd"].ToString() == null || memberAdded.Rows[0]["UserPswd"].ToString() == string.Empty)
                {
                    TextBox3.Visible = true;
                        bool memberAd = validationObj.PasswordSetBL(TextBox1.Text, TextBox3.Text);
                        if (memberAd)
                        {
                            Label1.Visible = true;
                            Label1.Text = "password Added Succesfully";
                        }
                        else
                        {
                            Label1.Visible = true;
                            Label1.Text = "password Not Added Succesfully";
                        }

                    }
            }
            
            catch (CustomException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
             LoginValidations validationObj = new LoginValidations();
            DataTable memberTable = new DataTable();
            
                try
                {
                    memberTable = validationObj.ValidateUserBL(TextBox1.Text, TextBox2.Text);
                    if (memberTable.Rows[0].ItemArray[2].ToString() == "Admin")
                    {
                        Label1.Visible = true;
                        Label1.Text = "Admin Page";
                    }
                    else if (memberTable.Rows[0].ItemArray[2].ToString() != "Admin")
                    {
                         Label1.Visible = true;
                        Label1.Text = "Employee Page";
                    }
                    else
                    {
                        Label1.Visible = true;
                        Label1.Text = "invalid data";
                    }
                }
            catch
                {
                    Label1.Visible = true;
                    Label1.Text = "UserName/Password is Invalid";
            }
               
            }

        }
    }
