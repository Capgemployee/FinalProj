﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.DAL;
using EMS.Entity;
using EMS.Exception;

namespace EMS.BL
{
    /// <summary>
    /// Class Name           :- Class to validate Admin information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
   public class AdminValidations
    {
        AdminOperations operationObj = new AdminOperations();

        public bool ValidateEmp(Employee employeeObj)
        {
            bool validdata = true;
            StringBuilder sb = new StringBuilder();

            if (validdata == false)
                throw new CustomException(sb.ToString());
            return validdata;
        }

        public bool ValidateProj(Project projectObj)
        {
            bool validdata = true;
            StringBuilder sb = new StringBuilder();


            if (validdata == false)
                throw new CustomException(sb.ToString());
            return validdata;
        }

        public bool AddRecordBL(Employee employeeObj)
        {
            bool employeeAdded = false;
            if (ValidateEmp(employeeObj))
                employeeAdded = operationObj.AddRecord(employeeObj);
            return employeeAdded;
        }

        public bool AdminUpdateRecordBL(Employee employeeObj)
        {
            bool employeeAdded = false;
            if (ValidateEmp(employeeObj))
                employeeAdded = operationObj.AdminUpdateRecord(employeeObj);
            return employeeAdded;
        }

        public DataTable DeleteRecordBL(int EmpID)
        {
            DataTable employeeDel = operationObj.DeleteRecord(EmpID);
            return employeeDel;
        }

        public DataTable SearchRecordBL(string param)
        {
            DataTable employeeSearch = operationObj.SearchRecord(param);
            return employeeSearch;
        }

        public bool AddProjectBL(Project projectObj)
        {
            bool employeeAdded = false;
            if (ValidateProj(projectObj))
                employeeAdded = operationObj.AddProject(projectObj);
            return employeeAdded;
        }

        public DataTable MyInfoBL(string UserID)
        {
            DataTable employeeSearch = operationObj.MyInfo(UserID);
            return employeeSearch;
        }

        public DataTable BirthdayBL()
        {
            DataTable employeeAdded = operationObj.Birthday();
            return employeeAdded;
        }
    }
}
