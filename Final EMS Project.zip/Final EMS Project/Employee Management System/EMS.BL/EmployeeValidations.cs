﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.DAL;
using EMS.Entity;
using EMS.Exception;

namespace EMS.BL
{
    /// <summary>
    /// Class Name           :- Class to validate Employee information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class EmployeeValidations
    {
        EmployeeOperations operationObj = new EmployeeOperations();

        public bool ValidateEmp(Employee employeeObj)
        {
            bool validdata = true;
            StringBuilder sb = new StringBuilder();

            if (validdata == false)
                throw new CustomException(sb.ToString());
            return validdata;
        }

        public bool EmpUpdateRecordBL(Employee employeeObj)
        {
            
            bool employeeAdded = false;
            if (ValidateEmp(employeeObj))
                employeeAdded = operationObj.EmpUpdateRecord(employeeObj);
            return employeeAdded;
        }

        public DataTable MyInfo(string UserID)
        {
            DataTable employeeSearch = operationObj.MyInfo(UserID);
            return employeeSearch;
        }

        public DataTable BirthdayBL()
        {
            DataTable employeeAdded = operationObj.Birthday();
            return employeeAdded;
        }

    }
}
